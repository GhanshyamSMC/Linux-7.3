#!/bin/bash
###			Data Gathering Uitlity version 2.06 
####################Path Definatination
tap_install_path=`pwd`
BROKER_ID=$(basename `pwd`) 
cd $tap_install_path
cd ..
Last_dir_name=$(basename `pwd`)
tap_dgu_path=/tmp/TAP/$BROKER_ID
INFO_LOG=/tmp/dgu_text_output.txt
ERROR_LOG=/tmp/dgu_text_error.txt
echo "TAP_INSTOLLATIN_PATH=$tap_instoll_path INFO_LOG=$INFO_LOG ERROR_LOG=$ERROR_LOG" >$INFO_LOG 2> $ERROR_LOG 
zipname="`basename $tap_dgu_path`" 2>> $ERROR_LOG 

#########################Abort Data gathering unint if invalid path execution

	if [ "$Last_dir_name" != "TAP" ]
	then
		echo "
			     tap_ip_dgu.sh script faild to execute from `basename $tap_install_path` directory
			
		Run the (./tap_ip_dgu.sh) from BROKER ID's directory for the proper execution of script on server "
		exit 1
	fi

################# Data and time parameter

Date=`date +%Y%m%d` 2>>$ERROR_LOG
Time=`date +%H%M%S` 2>>$ERROR_LOG

########## Dir Variable
BIN="BIN"
LOGS="LOGS"
FIX_LOGS="FIX_LOGS"
TAP_COMMON="TAP_COMMON" 


function Directory
 {
        cd  $tap_install_path
        ## Grep list of all directories except REPOSITORY in /tmp/tmp_dgu
        ls -lRt |sed -n '/^.\//p'|cut -d : -f1 |sed '/REPOSITORY/d' >/tmp/tmp_dgu

        if [ $? -ne 0 ]
        then
                echo "error detected while operation of directories in $tap_install_path listing in temp file excluding REPOSITORY." >>$ERROR_LOG
        fi

        for dir_name in `cat /tmp/tmp_dgu`
        do
                ## Directory creation for dgu
                mkdir -p $tap_dgu_path/$dir_name 2>>$ERROR_LOG
                if [ $? -ne 0 ]
                then
                         echo "error detected while directory creation $directory/$dir_name of DGU"  >>$ERROR_LOG
                fi

                ## Change the current directory.
                cd $tap_install_path/$dir_name

                ## Grep current date file names in /tap/tmp_dgu_date file.
                ls| grep $1 >/tmp/tmp_dgu_date

                if [ `wc -l /tmp/tmp_dgu_date |awk '{ print $1 }'` -ne 0 ] ##Do the copy if there is entry in fine
                then
                 	## Copy of current day logs
		        cp -p `cat /tmp/tmp_dgu_date` $tap_dgu_path/$dir_name  2>>$ERROR_LOG
                        if [ $? -ne 0 ]
                        then
                                echo "error detected while copy of $tap_install_path/$dir_name" >>$ERROR_LOG
                        fi

                fi

                ## Name is last value in directory list of /tmp/tmp_dgu

                name=`basename $dir_name`
			
                ## Copy all file in the directory if it is not LOGS,FIX_LOGS,BIN or TAP_COMMON
		if [ $name != $LOGS ]&& [ $name != $FIX_LOGS ] && [ $name != $BIN ] && [ "$name" != $TAP_COMMON ]
                then
                        ## ls -l |grep "^-" |awk '{print $9}'>/tmp/tmp_dgu_date
                        ## Grep current date file names in /tap/tmp_dgu_date file
                        ls >/tmp/tmp_dgu_date

                        if [ `wc -l /tmp/tmp_dgu_date |awk '{ print $1 }'` -ne 0 ]
                        then
                                cp -p `cat /tmp/tmp_dgu_date` $tap_dgu_path/$dir_name 2>>$ERROR_LOG
                                if [ $? -ne 0 ]
                                then
                                    echo "error detected while copy of $tap_install_path/$dir_name" >>$ERROR_LOG
                                fi

                        fi
                fi
		### Copy anly txt file in BIN and TAP_COMMON
                if [ "$name" = $BIN ] || [ "$name" = $TAP_COMMON ]
                then
                        ## Grep current date file names in /tap/tmp_dgu_date file
                        ls |grep ".txt" >/tmp/tmp_dgu_date

                        if [ `wc -l /tmp/tmp_dgu_date |awk '{ print $1 }'` -ne 0 ]
                        then
                                cp -p `cat /tmp/tmp_dgu_date` $tap_dgu_path/$dir_name 2>>$ERROR_LOG
                                if [ $? -ne 0 ]
                                then
                                        echo "error detected while copy of $tap_install_path/$dir_name" >>$ERROR_LOG
                                fi
                        fi

                fi
        done
 }

function System_info

 {
        echo "cat /etc/redhat-release">$tap_dgu_path/system_info.txt
        cat /etc/redhat-release >>$tap_dgu_path/system_info.txt
        echo "cat /etc/issue">>$tap_dgu_path/system_info.txt
        cat /etc/issue>>$tap_dgu_path/system_info.txt

        echo " HARDWARE INFORMAION ">$tap_dgu_path/hardware_info.txt
        echo "cat /proc/cpuinfo">>$tap_dgu_path/hardware_info.txt
        cat /proc/cpuinfo >>$tap_dgu_path/hardware_info.txt
        echo "======================================================================">>$tap_dgu_path/hardware_info.txt

        echo "cat /proc/meminfo">>$tap_dgu_path/hardware_info.txt
        cat /proc/meminfo>>$tap_dgu_path/hardware_info.txt

        echo "netstat -na">$tap_dgu_path/network_info.txt
        netstat -na >>$tap_dgu_path/network_info.txt

        echo "free -m">$tap_dgu_path/memory_info.txt
        free -m >>$tap_dgu_path/memory_info.txt

        echo "ps -Leaf">$tap_dgu_path/process_info.txt
        ps -Leaf>>$tap_dgu_path/process_info.txt

        echo "uname -a">$tap_dgu_path/kernal_info.txt
        uname -a>>$tap_dgu_path/kernal_info.txt

        echo "Tap registry for $BROKER_ID ">$tap_dgu_path/tap_info.txt
        cat "/etc/TAP_REGISTRY/$BROKER_ID" >>$tap_dgu_path/tap_info.txt

        echo "system disk space of `hostname`" >$tap_dgu_path/system_disk_space.txt
        df -h >>$tap_dgu_path/system_disk_space.txt

        echo -e "\n     TIME INFORMATION AND TIME ZONE  \n" >$tap_dgu_path/time_info.txt
        echo "Date : `date`" >>$tap_dgu_path/time_info.txt
        echo "Time Zone:`date +%Z`">>$tap_dgu_path/time_info.txt
        echo "Time zone of `date +%Z` is UTC `date +%::z`">>$tap_dgu_path/time_info.txt
	
	echo "Last reboot and Uptime Information" >$tap_dgu_path/Uptime_info.txt
	echo "Uptime of the system is as below">>$tap_dgu_path/Uptime_info.txt
	uptime >>$tap_dgu_path/Uptime_info.txt
	echo "Last reboot information" >>$tap_dgu_path/Uptime_info.txt
	who -b >>$tap_dgu_path/Uptime_info.txt
 }


Directory `date +%Y%m%d` 2>> $ERROR_LOG 
System_info 2>> $ERROR_LOG

cd /tmp

#################################### After proper execution zipname has value of Broker_Number
zipname_test=$zipname
zipname="./TAP/$zipname_test"

zip -r "TAP_ANALYSIS_$Date"_"$Time.zip" $zipname  >>$INFO_LOG
       if [ $? -ne 0 ]
       then
      		 echo "error detected while zip operation of DGU"  >>$ERROR_LOG
       fi

cp $INFO_LOG $tap_install_path/TAP_DGU/BIN/dgu_text_output.txt
cp $ERROR_LOG  $tap_install_path/TAP_DGU/BIN/dgu_text_error.txt

cp $INFO_LOG $tap_dgu_path/TAP_DGU/BIN/dgu_text_output.txt
cp $ERROR_LOG  $tap_dgu_path/TAP_DGU/BIN/dgu_text_error.txt

rm -rf /tmp/tmp_dgu_date /tmp/tmp_dgu /tmp/Last_dir_name TAP 

echo -e "\n \t\t\t Your log file is at /tmp/TAP_ANALYSIS_$Date"_"$Time.zip \n"
############################################################################################################################
