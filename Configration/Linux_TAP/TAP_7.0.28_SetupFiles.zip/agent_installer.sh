#!/bin/bash
#Installer of TAP AGENT on LINUX
#Date		Description
#24/01/2011	TAP Agent Setup Version 1.0.RC5
#               

USER_ID=$(id -u)
	if [ $USER_ID -ne 0 ];then
       		echo "Kindly ensure TAP Agent Installation is done using \"root\" login."
       		exit
	fi

TAP=TAP

rm -f "/tmp/TAP_AGENT_InstallationDetails.log"
value=$?
if [ $value -ne 0 ]; then
	echo "Error while deletion in log file TAP_AGENT_InstallationDetails.log"
	exit
fi

#Tap agent installation logs files.
touch "/tmp/TAP_AGENT_InstallationDetails.log"
LOG="/tmp/TAP_AGENT_InstallationDetails.log"

#It holds the Installation Versions
AGENT_VERSION=1.06
AGENT_INSTALLER_VERSION=1.06
AGENT_UNINSTALLER_VERSION=1.01
AGENT_MONITORING_VERSION=1.01
AGENT_STATUS_FLAG=0
BROKER_ID=

#It holds the Installation directory of TAP
InstallDir="/usr/bin/$TAP"

>$LOG

#It holds the TAP Registry file path
REGISTRY_FILE="/etc/tap_agent_registry.txt"
REGISTRY_DIRECTORY="/etc/TAP_REGISTRY"
#REGISTRY_FILE="$REGISTRY_DIRECTORY/$BROKER_ID"
#It holds the setup zip file name which contains all setup files.
Setup_zip_file="TAP_AGENT_"$AGENT_INSTALLER_VERSION"_SetupFiles.zip"

#SetupFilesPath is the path for tap agent zip extraction.
SetupFilesPath="/tmp/TAP_Agent_Files" 2>>$LOG

#Flags used to decide whether fresh or upgrade of agent installation.
UPGRADE_FLAG=0
AGENT_UNINSTALLER_UPGRADE_FLAG=0
AGENT_MONITORING_UPGRADE_FLAG=0

#Header in the repo config file
PATHS_PARAM=PATHS
NUMBER_OF_LOGS_PARAM=NUMBER_OF_LOGS

#Headers in the tap registry file
ROOT_NAME=ROOT
SECTION_NAME=SECTION
VERSION_NAME=VERSION

#Parameters from the registry file under VERSION header
AGENT_UNINSTALLER_VERSION_PARAM=AGENT_UNINSTALLER_VERSION
AGENT_VERSION_PARAM=AGENT_VERSION
AGENT_MONITORING_VERSION_PARAM=AGENT_MONITORING_VERSION

#Parameters from the registry file under ROOT header
VERSION_PARAM="VERSION"
PATH_PARAM="PATH"
REPO_CONFIG_FILE_PATH_PARAM="REPO_CONFIG_FILE_PATH"
CONFIG_FILE_PATH_PARAM="CONFIG_FILE_PATH"
TAP_AGENT_PATH_PARAM="TAP_AGENT_PATH"
BROKER_ID_PARAM="BROKER_ID"

# Value of Repository index TAP_REPO_MAX_INDEX
NUMBER_OF_LOGS=20
AGENT_INDEX=13

#It holds the path for cron entry
CRON_USER="root"
PATH_FOR_CRON_ENTRY="/var/spool/cron/root"

#It holds the time for cron to run
TASK_EXEC_TIME_MONITORING="00 02 * * *"
TASK_EXEC_TIME_MONITORING_ONREBOOT="@reboot"
TASK_COMMAND_MONITORING="$InstallDir/TAP_AGENT/BIN/restart_agent_monitoring.sh"
TASK_COMMAND_RESTART_MONITORING="$InstallDir/TAP_AGENT/restart_agent_monitoring.sh"
TAP_REPO_INI="$InstallDir/TAP_REPO_MANAGEMENT/CONFIG/tap_repo.ini"


function Status_check()
{
#      	echo "------------------------------------START TAP_AGENT---------------------------------" | tee -a $LOG
#	echo "Installing TAP Agent." |tee -a $LOG
      	echo "------------------------------------START TAP_AGENT---------------------------------" >> $LOG
 	echo "Installing TAP Agent." >> $LOG
	# Check if TAP is installed or not on this machine.
	#if [ ! -f /etc/tap_registry.txt ];then
    #    echo "Error while installation - tap_registry file not found" |tee -a $LOG
	#	exit
	#fi

	 #Check if TAP is installed or not on this machine.
	if [ ! -f "$REGISTRY_DIRECTORY/$BROKER_ID" ];then
        echo "Error while installation - tap_registry $REGISTRY_DIRECTORY/$BROKER_ID file not found" |tee -a $LOG
		exit
	fi


	mkdir -p $SetupFilesPath  2>>$LOG
	if [ ! -d $SetupFilesPath ];then
		echo "Cannot create SetupFilesPath directory." | tee -a $LOG
		exit
	fi

	unzip -o $Setup_zip_file -x -d $SetupFilesPath >>$LOG
	value=$?
	if [ $value -ne 0 ];then
		echo "Cannot unzip $Setup_zip_file." | tee -a $LOG
		exit
	fi
	echo "All files extracted" >> $LOG
	cd "$SetupFilesPath/exe"
	chmod -R 777 "$SetupFilesPath" >> $LOG
	echo "All permissions granted to Setup Files" >> $LOG

}

function AbortInstall()
{
	if [  $UPGRADE_FLAG -eq 1 ]; then

		# kill agent monitoring if running
		process_count=`/bin/ps ax |/bin/grep -w agent_monitoring_service.sh|grep -v "grep"|wc -l`
		if [ $process_count -ne 0 ] ;then
			process_id=`/bin/ps ax |/bin/grep -w agent_monitoring_service.sh|grep -v "grep"|awk '{ print $1 }' ` >>$LOG 2>>$LOG
			value=$?
			if [ $value -ne 0 ]; then
				echo "PID detection of agent_monitoring_service failed.Return value: $value" | tee -a $LOG
			fi
			kill -9 $process_id 2>>$LOG
		fi

		# kill tap agent if running

		process_count=`/bin/ps ax |/bin/grep -w tap_agent|grep -v "grep"|wc -l`
		if [ $process_count -ne 0 ] ;then
			process_id=`/bin/ps ax |/bin/grep -w tap_agent|grep -v "grep"|awk '{ print $1 }' ` >>$LOG 2>>$LOG
			value=$?
			if [ $value -ne 0 ]; then
				echo "PID detection of tap_agent failed.Return value: $value" | tee -a $LOG
			fi
			kill -9 $process_id 2>>$LOG

		fi
	fi

#	Cleanup of AGENT
	rm -Rf "$InstallDir/TAP_AGENT"
	rm -Rf "$REGISTRY_FILE"
	echo "TAP AGENT Installation failed." | tee -a $LOG

	echo "Removing schedular entries" >> $LOG
	echo "Copy of cron entry is kept at /tmp/cron_backup" >> $LOG
	cp -f $PATH_FOR_CRON_ENTRY "/tmp/cron_backup"
	sed '/restart_agent_monitoring.sh/d' $PATH_FOR_CRON_ENTRY > /tmp/new_cron_file.txt
	diff $PATH_FOR_CRON_ENTRY /tmp/new_cron_file.txt >> $LOG

	cp -f /tmp/new_cron_file.txt $PATH_FOR_CRON_ENTRY
	value=$?
	if [ $value -ne 0 ]; then
		echo "Copy of /tmp/new_cron_file.txt to the $PATH_FOR_CRON_ENTRY failed: Return value: $value" | tee -a $LOG
		echo "Reverting back /tmp/cron_backup to $PATH_FOR_CRON_ENTRY" | tee -a $LOG
		cp -f /tmp/cron_backup $PATH_FOR_CRON_ENTRY >> $LOG
		echo "TAP agent installation failed." | tee -a $LOG
	fi

	# TAP_REPO_INI entries removal from repo_ini file of tap
	cp $TAP_REPO_INI /tmp/repo_ini_bkp.txt 2>>$LOG
	
	sed   '/TAP_AGENT/d' $TAP_REPO_INI > /tmp/new_repo_file.txt 2>>$LOG
	cp /tmp/new_repo_file.txt $TAP_REPO_INI

	value=$?
	if [ $value -ne 0 ]; then
		echo "Copy of /tmp/new_repo_file.txt to the $TAP_REPO_INI failed: Return value: $value" | tee -a $LOG
		echo "Reverting back /tmp/repo_ini_bkp.txt to $TAP_REPO_INI" | tee -a $LOG
		cp -f /tmp/repo_ini_bkp.txt $TAP_REPO_INI 2>> $LOG
		echo "Remove repository entry of tap agent manually" | tee -a $LOG
	fi		
	OnExitInstall
}
function OnExitInstall()
{
	#Cleanup activites to be done here
	rm -Rf "$SetupFilesPath" >>$LOG
	echo "SetupFiles cleaned up." >> $LOG
	chmod -R 777 "$InstallDir/TAP_AGENT" >> $LOG 2>>$LOG
	chmod -R 777 $REGISTRY_FILE >> $LOG 2>>$LOG
#	echo "-------------------------------------END TAP_AGENT----------------------------------" | tee -a $LOG
	echo "-------------------------------------END TAP_AGENT----------------------------------" >> $LOG

	exit
}

function Oninit()
{	
	if [ ! -f $REGISTRY_FILE ];then
		echo "TAP agent registry file is not present." >> $LOG
		UPGRADE_FLAG=0
	else
	#	Upgrade Case of tap agent
		./config_utility -sg "$REGISTRY_FILE" "$VERSION_NAME" "$AGENT_VERSION_PARAM" 2>>$LOG
		value=$?
		if [ $value -ne 0 ];then
			echo "Cannot find VERSION_NAME entry in registry file" | tee -a $LOG
			UPGRADE_FLAG=0
		else
			registry_value=`cat tap_val.txt`2>>$LOG
			echo -n $(cat tap_val.txt |cut -d "." -f 1)>tap_agent.txt
			echo -n $(cat tap_val.txt |cut -d "." -f 2)>>tap_agent.txt
			CURRENT_VERSION=`cat tap_agent.txt`

			echo -n $(echo $AGENT_VERSION |cut -d "." -f 1)>tap_agent.txt
			echo -n $(echo $AGENT_VERSION |cut -d "." -f 2)>>tap_agent.txt
			AGENT_VERSION_NEW=`cat tap_agent.txt`

			if [ $CURRENT_VERSION -lt $AGENT_VERSION_NEW ];then
				UPGRADE_FLAG=1
			else
				echo "You have the latest version of tap agent" >>$LOG  2>> $LOG
				process_count=`/bin/ps ax |/bin/grep -w tap_agent|grep -v "grep"|wc -l`
				if [ $process_count -ne 0 ] ;then
					process_id=`/bin/ps ax |/bin/grep -w tap_agent|grep -v "grep"|awk '{ print $1 }' ` >>$LOG 2>>$LOG
					kill -9 $process_id 2>>$LOG
					value=$?
					if [ $value -ne 0 ]; then
						echo "Kill of tap_agent failed. Return value: $value" | tee -a $LOG
						AbortInstall 
					fi
				fi

				OnExitInstall
			fi

			#Agent Uninstaller
			./config_utility -sg "$REGISTRY_FILE" "$VERSION_NAME" "$AGENT_UNINSTALLER_VERSION_PARAM" 2>>$LOG
			value=$?
			if [ $value -ne 0 ];then
				echo "Cannot find Agent Uninstaller entry in registry file" | tee -a $LOG
				Abortinstall 0
			fi

			registry_value=`cat tap_val.txt` >>$LOG
			echo -n $(cat tap_val.txt |cut -d "." -f 1)>tap_agent.txt
			echo -n $(cat tap_val.txt |cut -d "." -f 2)>>tap_agent.txt

			CURRENT_VERSION=`cat tap_agent.txt`

			echo -n $(echo $AGENT_UNINSTALLER_VERSION |cut -d "." -f 1)>tap_agent.txt
			echo -n $(echo $AGENT_UNINSTALLER_VERSION |cut -d "." -f 2)>>tap_agent.txt
			AGENT_UNINSTALLER_VERSION_NEW=`cat tap_agent.txt`

			if [ $CURRENT_VERSION -lt $AGENT_UNINSTALLER_VERSION_NEW ];then
				AGENT_UNINSTALLER_UPGRADE_FLAG=1
			else
				#echo "You have the latest version of tap agent uninstaller " | tee -a $LOG
				echo "You have the latest version of tap agent uninstaller " >> $LOG
				echo "Uninstaller UPGRADE_FLAG = $AGENT_UNINSTALLER_UPGRADE_FLAG which is default value" >>$LOG
			fi
			
			#Agent Monitoring
			./config_utility -sg "$REGISTRY_FILE" "$VERSION_NAME" "$AGENT_MONITORING_VERSION_PARAM" 2>>$LOG
			value=$?
			if [ $value -ne 0 ];then
				echo "Cannot find Agent Monitoring entry in registry file" | tee -a $LOG
				Abortinstall
			fi
			
			registry_value=`cat tap_val.txt`2>>$LOG
			echo -n $(cat tap_val.txt |cut -d "." -f 1)>tap_agent.txt
			echo -n $(cat tap_val.txt |cut -d "." -f 2)>>tap_agent.txt

			CURRENT_VERSION=`cat tap_agent.txt`

			echo -n $(echo $AGENT_MONITORING_VERSION |cut -d "." -f 1)>tap_agent.txt
			echo -n $(echo $AGENT_MONITORING_VERSION |cut -d "." -f 2)>>tap_agent.txt
			AGENT_MONITORING_VERSION_NEW=`cat tap_agent.txt`

			if [ $CURRENT_VERSION -lt $AGENT_MONITORING_VERSION_NEW ];then
				AGENT_MONITORING_UPGRADE_FLAG=1
				echo  "Monitoring  UPGRADE_FLAG = $AGENT_MONITORING_UPGRADE_FLAG" >>$LOG
				echo  "which is upgrade status of monitoring value" >>$LOG
			else
				echo "You have the latest version of tap agent monitoring" >>$LOG
				AGENT_MONITORING_UPGRADE_FLAG=0
			fi
		fi
	fi
}

function Get_InstallPath ()
{
	./config_utility -sg "$REGISTRY_DIRECTORY/$BROKER_ID" "$ROOT_NAME" "$PATH_PARAM" 2>>$LOG
	value=$?
	if [ $value -ne 0 ];then
		echo "Cannot find TAP installation path in tap registry file" | tee -a $LOG
		exit
	fi

	InstallDir=`cat tap_val.txt`

	# Redefine following variables using new value of InstallDir

	TASK_COMMAND_MONITORING="$InstallDir/TAP_AGENT/BIN/restart_agent_monitoring.sh"
	TASK_COMMAND_RESTART_MONITORING="$InstallDir/TAP_AGENT/restart_agent_monitoring.sh"
	TAP_REPO_INI="$InstallDir/TAP_REPO_MANAGEMENT/CONFIG/tap_repo.ini"
}


function PreInstall()
{

if [ $UPGRADE_FLAG -eq 1  ];then

	# AGENT_UPGRADE wrt Flag Value
	# Partial name to kill tap_gaent and  agent_monitoring

	process_count=`/bin/ps ax |/bin/grep -w agent_monitoring_service.sh|grep -v "grep"|wc -l`
	if [ $process_count -ne 0 ] ;then
		process_id=`/bin/ps ax |/bin/grep -w agent_monitoring_service.sh|grep -v "grep"|awk '{ print $1 }' ` >>$LOG 2>>$LOG
		kill -9 $process_id 2>>$LOG
		value=$?
		if [ $value -ne 0 ]; then
			echo "Kill of agent_monitoring_service failed. Return value: $value" | tee -a $LOG
			AbortInstall 
		fi
	fi

	process_count=`/bin/ps ax |/bin/grep -w tap_agent|grep -v "grep"|wc -l`
	if [ $process_count -ne 0 ] ;then
		process_id=`/bin/ps ax |/bin/grep -w tap_agent|grep -v "grep"|awk '{ print $1 }' ` >>$LOG 2>>$LOG
		kill -9 $process_id 2>>$LOG
		value=$?
		if [ $value -ne 0 ]; then
			echo "Kill of tap_agent failed. Return value: $value" | tee -a $LOG
			AbortInstall 
		fi
	fi

	rm -f "$InstallDir/TAP_AGENT/BIN/tap_agent"
	value=$?
	if [ $value -ne 0 ]; then
		echo "Delete of tap_agent failed. Return value: $value" | tee -a $LOG
		AbortInstall 
	fi

	cp -pf "$SetupFilesPath/exe/tap_agent" "$InstallDir/TAP_AGENT/BIN"
	value=$?
	if [ $value -ne 0 ]; then
		echo "Copying of tap_agent failed. Return value: $value" | tee -a $LOG
		AbortInstall 
	fi

	./config_utility -sm $REGISTRY_FILE $VERSION_NAME $AGENT_VERSION_PARAM $AGENT_VERSION
	value=$?
	if [ $value -ne 1 ]; then
		echo "Unable to write $AGENT_VERSION_PARAM to the registry file. Return value: $value" | tee -a $LOG
		AbortInstall 
	fi

# UNINSTALLER_UPGRADE wrt Flag Value

	if [ $AGENT_UNINSTALLER_UPGRADE_FLAG -eq 1 ];then
		rm -f "$InstallDir/TAP_AGENT/agent_uninstaller.sh"
		value=$?
		if [ $value -ne 0 ]; then
			echo "Delete of agent_uninstaller.sh failed. Return value: $value" | tee -a $LOG
			AbortInstall 
		fi
	

		cp -pf "$SetupFilesPath/exe/agent_uninstaller.sh" "$InstallDir/TAP_AGENT"
		value=$?
		if [ $value -ne 0 ]; then
			echo "Copying of agent_uninstaller.sh failed. Return value: $value" | tee -a $LOG
			AbortInstall 
		fi

		./config_utility -sm $REGISTRY_FILE $VERSION_NAME $AGENT_UNINSTALLER_VERSION_PARAM $AGENT_UNINSTALLER_VERSION
		value=$?
		if [ $value -ne 1 ]; then
			echo -n "Unable to write $AGENT_UNINSTALLER_VERSION_PARAM to the registry file." | tee -a $LOG
			echo   " Return value: $value" | tee -a $LOG
			AbortInstall 
		fi
	fi
# AGENT_MONITORING_UPGRADE wrt Flag Value

	if [ $AGENT_MONITORING_UPGRADE_FLAG -eq 1 ];then
		rm -f "$InstallDir/TAP_AGENT/BIN/agent_monitoring_service.sh"
		value=$?
		if [ $value -ne 0 ]; then
			echo "Delete of agent_monitoring_service.sh failed. Return value: $value" | tee -a $LOG
			AbortInstall 
		fi
	

		cp -pf "$SetupFilesPath/exe/agent_monitoring_service.sh" "$InstallDir/TAP_AGENT/BIN"
		value=$?
		if [ $value -ne 0 ]; then
			echo "Copy of agent_monitoring_service.sh failed. Return value: $value" | tee -a $LOG
			AbortInstall 
		fi

		./config_utility -sm $REGISTRY_FILE $VERSION_NAME $AGENT_MONITORING_VERSION_PARAM $AGENT_MONITORING_VERSION
		value=$?
		if [ $value -ne 1 ]; then
			echo "Unable to write $AGENT_MONITORING_VERSION_PARAM to the registry file. Return value: $value" | tee -a $LOG
			AbortInstall 
		fi
	fi
else
#Fresh installation case for tap_agent
	# AGENT_Install wrt Flag Value
	#/usr/bin/TAP_IP/TAP_AGENT/
	#Read TAP PATH

	#Making the registry file entries.
	if [ ! -f $REGISTRY_FILE ]; then
		echo "Creating tap_agent_registry.txt file" >> $LOG
		touch "$REGISTRY_FILE"
		value=$?
		if [ $value -ne 0 ]; then
			echo "Creation of $REGISTRY_FILE file failed. Return value: $value" | tee -a $LOG
			AbortInstall 
		fi
	fi

	#Install all the common tools
	if [ ! -d "$InstallDir/TAP_AGENT" ]; then
		echo "Creating $InstallDir/TAP_AGENT" >> $LOG
		mkdir $InstallDir/TAP_AGENT
		value=$?
		if [ $value -ne 0 ]; then
			echo "Creation of $InstallDir/TAP_AGENT directory failed. Return value: $value" | tee -a $LOG
			AbortInstall 
		fi
	fi
	#Writing of PATH in the registry file
	echo "Writing of PATH in the registry file" >> $LOG

	./config_utility -sa $REGISTRY_FILE $ROOT_NAME $PATH_PARAM $InstallDir
	value=$?
	if [ $value -ne 1 ]; then
		echo "Unable to write PATH to the registry file. Return value: $value" | tee -a $LOG
		AbortInstall 
	fi

	chmod -R 777 $InstallDir/TAP_AGENT >> $LOG
	echo "All permissions granted" >> $LOG

	# Installation of Tap_Agent services.
	if [ ! -d "$InstallDir/TAP_AGENT/BIN" ]; then
		echo "Creating $InstallDir/TAP_AGENT/BIN directory" >> $LOG
		mkdir -p $InstallDir/TAP_AGENT/BIN
		value=$?
		if [ $value -ne 0 ]; then
			echo "Creation of $InstallDir/TAP_AGENT/BIN directory failed. Return value: $value" | tee -a $LOG
			AbortInstall 
		fi
	fi

	echo "Copying tap_agent" >> $LOG
	cp -p "$SetupFilesPath/exe/tap_agent" "$InstallDir/TAP_AGENT/BIN"
	value=$?
	if [ $value -ne 0 ]; then
		echo "Copying of tap_agent failed. Return value: $value" | tee -a $LOG
		AbortInstall 
	fi

	TAP_AGENT_PATH_FILE=$(echo $InstallDir/TAP_AGENT/BIN/tap_agent)
	./config_utility -sa $REGISTRY_FILE $ROOT_NAME $TAP_AGENT_PATH_PARAM $TAP_AGENT_PATH_FILE
	value=$?
	if [ $value -ne 1 ]; then
		echo "Unable to write TAP_AGENT_PATH to the registry file. Return value: $value" | tee -a $LOG
		AbortInstall 
	fi

	echo "Copying tap_agent_uninstaller" >> $LOG
	cp -p "$SetupFilesPath/exe/agent_uninstaller.sh" "$InstallDir/TAP_AGENT"
	value=$?
	if [ $value -ne 0 ]; then
		echo "Copying of agent_uninstaller.sh failed Return value: $value" | tee -a $LOG
		AbortInstall 
	fi

	echo "Copying agent_monitoring_service.sh " >> $LOG
	cp -p "$SetupFilesPath/exe/agent_monitoring_service.sh" "$InstallDir/TAP_AGENT/BIN"
	value=$?
	if [ $value -ne 0 ]; then
		echo "Copying of agent_monitoring_service.sh failed. Return value: $value" | tee -a $LOG
		AbortInstall 
	fi

	if [ ! -d "$InstallDir/TAP_AGENT/CONFIG" ]; then
		echo "Creating $InstallDir/TAP_AGENT/CONFIG directory" >> $LOG
		mkdir $InstallDir/TAP_AGENT/CONFIG
		value=$?
		if [ $value -ne 0 ]; then
			echo "Creation of $InstallDir/TAP_AGENT/CONFIG directory failed. Return value: $value" | tee -a $LOG
			AbortInstall 
		fi
	fi

	echo "Copying tap_agent.ini" >> $LOG
	cp -p "$SetupFilesPath/config/tap_agent.ini" "$InstallDir/TAP_AGENT/CONFIG"
	value=$?
	if [ $value -ne 0 ]; then
		echo "Copying of tap_agent.ini failed Return value: $value" | tee -a $LOG
		AbortInstall 
	fi

	TAP_AGENT_CONFIG_FILE=$(echo $InstallDir/TAP_AGENT/CONFIG/tap_agent.ini)
	
	#Writing of Broker ID in the configuration file
	echo "Writing of BrokerID in the configuration file" >> $LOG
	./config_utility -m $TAP_AGENT_CONFIG_FILE $BROKER_ID_PARAM $BROKER_ID
    value=$?
	if [ $value -ne 1 ]; then
		echo "Cannot write $BROKER_ID_PARAM to the tap_agent.ini file Return value: $value" | tee -a $LOG
		AbortInstall
	fi

	./config_utility -sa $REGISTRY_FILE $ROOT_NAME $CONFIG_FILE_PATH_PARAM \
	$TAP_AGENT_CONFIG_FILE
	value=$?
	if [ $value -ne 1 ]; then
		echo "Unable to write CONFIG_FILE_PATH to the registry file. Return value: $value" | tee -a $LOG
		AbortInstall 
	fi

	if [ ! -d "$InstallDir/TAP_AGENT/LOGS" ]; then
		echo "Creating $InstallDir/TAP_AGENT/LOGS directory" >> $LOG
		mkdir $InstallDir/TAP_AGENT/LOGS
		value=$?
		if [ $value -ne 0 ]; then
			echo "Creation of $InstallDir/TAP_AGENT/LOGS directory failed. Return value: $value" | tee -a $LOG
			AbortInstall 
		fi
	fi
	
	echo "Copying restart_agent_monitoring.sh" >> $LOG
	cp -p "$SetupFilesPath/exe/restart_agent_monitoring.sh" "$InstallDir/TAP_AGENT/BIN"
	value=$?
	if [ $value -ne 0 ]; then
		echo "Copying of restart_agent_monitoring.sh failed. Return value: $value" | tee -a $LOG
		AbortInstall 
	fi

	if [ ! -d "$InstallDir/TAP_AGENT/REPOSITORY" ]; then
		echo "Creating $InstallDir/TAP_AGENT/REPOSITORY directory" >> $LOG
		mkdir $InstallDir/TAP_AGENT/REPOSITORY
		value=$?
		if [ $value -ne 0 ]; then
			echo "Creation of $InstallDir/TAP_AGENT/REPOSITORY directory failed. Return value: $value" | tee -a $LOG
			AbortInstall 
		fi
	fi

	if [ $UPGRADE_FLAG -eq 0 ]; then
		#Modifying of AGENT_VERSION_PARAM in the registry file
		echo "Modifying AGENT_VERSION_PARAM in the registry file" >> $LOG
		./config_utility -sm $REGISTRY_FILE $VERSION_NAME $AGENT_VERSION_PARAM $AGENT_VERSION
		value=$?
		if [ $value -ne 1 ]; then
			echo "Unable to write $AGENT_VERSION_PARAM to the registry file. Return value: $value" | tee -a $LOG
			AbortInstall 
		fi
	fi

	if [ $AGENT_UNINSTALLER_UPGRADE_FLAG -eq 0 ]; then
		#Modifying of AGENT_UNINSTALLER_VERSION_PARAM in the registry file
		echo "Modifying AGENT_UNINSTALLER_VERSION_PARAM in the registry file" >> $LOG
		./config_utility -sm $REGISTRY_FILE $VERSION_NAME $AGENT_UNINSTALLER_VERSION_PARAM $AGENT_UNINSTALLER_VERSION
		value=$?
		if [ $value -ne 1 ]; then
			echo "Unable to write $UNINSTALLER_VERSION_PARAM to the registry file. Return value: $value" | tee -a $LOG
			AbortInstall 
		fi
	fi

	if [ $AGENT_MONITORING_UPGRADE_FLAG -eq 0 ]; then
		# Modifying of AGENT_MONITORING_VERSION_PARAM in the registry file
		echo "Modifying AGENT_MONITORING_VERSION_PARAM in the registry file" >> $LOG
		./config_utility -sm $REGISTRY_FILE $VERSION_NAME $AGENT_MONITORING_VERSION_PARAM $AGENT_MONITORING_VERSION
		value=$?
		if [ $value -ne 1 ]; then
			echo "Unable to write $AGENT_MONITORING_VERSION_PARAM to the registry file. Return value: $value" | tee -a $LOG
			AbortInstall 
		fi
	fi

	# Check Cron Path For Modification
	
	TASK_COMMAND_MONITORING="$InstallDir/TAP_AGENT/BIN/restart_agent_monitoring.sh"
	
	TASK_COMMAND_RESTART_MONITORING="$InstallDir/TAP_AGENT/BIN/restart_agent_monitoring.sh"

	# Creating schedular entries

	echo "Creating schedular entry for monitoring service" >> $LOG

	echo "$TASK_EXEC_TIME_MONITORING $TASK_COMMAND_RESTART_MONITORING" >> $PATH_FOR_CRON_ENTRY
	value=$?
	if [ $value -ne 0 ]; then
		echo "Cron entry of restart TAP_Agent and agent_monitoring at 2.00 AM failed. Return value: $value" | tee -a $LOG
		AbortInstall 
	fi

	echo "$TASK_EXEC_TIME_MONITORING_ONREBOOT $TASK_COMMAND_MONITORING" >> $PATH_FOR_CRON_ENTRY
	value=$?
	if [ $value -ne 0 ]; then
		echo "Cron entry of Monitoring service on reboot failed. Return value: $value" | tee -a $LOG
		AbortInstall 
	fi

	RepoEntry

fi

cd $InstallDir/TAP_AGENT/BIN 
./agent_monitoring_service.sh & >>$LOG 2>>$LOG
sleep 5
# echo "TAP AGENT has been installed successfully on your machine." | tee -a $LOG
echo "TAP AGENT has been installed successfully on your machine." >> $LOG

}

function RepoEntry()
{
	# Define new path of TAP_REPO_INI 
	TAP_REPO_INI="$InstallDir/TAP_REPO_MANAGEMENT/CONFIG/tap_repo.ini"

	cp -f $TAP_REPO_INI /tmp/repo_ini.bkp

	#Check the install case and add the value in RepoEntry if it is not found delete the install case.

	REPO_ENTRY=`cat $TAP_REPO_INI | grep "NUMBER_OF_LOGS" |cut -d = -f 2` 2>>$LOG
	value=$?
	if [ $value -ne 0 ];then
		echo " NUMBER_OF_LOGS entry not found in tap_repo.ini file" | tee -a $LOG
		AbortInstall 
	fi

	if [ $REPO_ENTRY -lt $NUMBER_OF_LOGS ];then

		./config_utility -sm $TAP_REPO_INI PATHS $NUMBER_OF_LOGS_PARAM $NUMBER_OF_LOGS
		value=$?
		if [ $value -ne 1 ];then
			echo "Unable to write $NUMBER_OF_LOGS_PARAM to the registry file. Return value: $value" | tee -a $LOG
			AbortInstall 
		fi
	fi

	COUNT=$(cat $TAP_REPO_INI |grep LOG_FILE_PATH_$AGENT_INDEX |wc -l)
	if [ $COUNT -eq 0 ];then
		echo "LOG_FILE_PATH_$AGENT_INDEX=../../TAP_AGENT/LOGS" >>$TAP_REPO_INI
	fi

	COUNT=$(cat $TAP_REPO_INI |grep REPOSITORY_FILE_PATH_$AGENT_INDEX |wc -l)
	if [ $COUNT -eq 0 ];then
		echo "REPOSITORY_FILE_PATH_$AGENT_INDEX=../../TAP_AGENT/REPOSITORY" >>$TAP_REPO_INI
	fi

}
BROKER_ID=$1
Status_check
Get_InstallPath
Oninit
PreInstall
OnExitInstall

