#!/bin/bash
#Installer of NOW/NORMAL TAP RDM on LINUX
#Date		Description
#13/04/2013	7.0.3	Linux RDM Setup Installer Version, RDM(7.0 RC3) Box version(70108)
# TCMS =2.06, UNINSTALLER_VER=2.10
#

INSTALLER_VERSION=7.0.14
PRODUCT_VERSION=7.0
#MARKET_INDEX= CM=1, FO=2, WDM=3, IPO=4, CD=5, SLBM=6, MF=7, RDM=8
#It holds the market index corresponding to market name.
MARKET_INDEX=8

TAP=TAP

USER_ID=$(id -u)
if [ $USER_ID -ne 0 ]; then
        echo "Kindly ensure TAP Installation is done using \"root\" login."
        exit
fi
#rm -f "/tmp/TAP_InstallationDetails.log"
#value=$?
#if [ $value -ne 0 ]; then
#        echo "Error while deletion of log file TAP_InstallationDetails.log"
#        exit
#fi
touch "/tmp/TAP_InstallationDetails.log"
LOG="/tmp/TAP_InstallationDetails.log"

#Versions of the markets
TAP_RDM_VER=7.14

#Versions of the common tools
TCMS_IP_VER=2.10
RMS_VER=6.02
DGU_VER=2.06
TAP_MONITORING_VER=6.02
UNINSTALLER_VER=2.12

#TAP config parameter
MAX_TWS_CLIENTS_VALUE="400"
MKTCONFIG_FILE_PATH="../CONFIG/rdm_mkt_config.dat"
NIPCONFIG_FILE_PATH="../CONFIG/rdm_nip_config.dat"

#decimal registry entries
KEEP_ALIVE_INTERVAL="2"
KEEP_ALIVE_TIME="20"
TCP_KEEPALIVE_PROBES="5"


#It holds the time for cron to run
TASK_EXEC_TIME_REPO="00 04 * * *"
TASK_EXEC_TIME_REPO_ONREBOOT="@reboot"
TASK_EXEC_TIME_MONITORING_ONREBOOT="@reboot"

#It holds the final broker IDs for which installation/upgradation will be done.
BROKER_ID_FILE="/tmp/brokerid_list_rdm.txt"

#It holds the registry file names present in the registry.
BROKER_ID_TEMP_FILE="/tmp/brokerid_temp.txt"

#It holds the count of brokers installed.
COUNT_OF_BROKERS="0"

#It holds the successfull installation count of brokers
SUCCESS_COUNT=0

#Used for logging of Installation summary
LogBuffer=

#Used for storing the root directory of TAP
TAP_ROOT_DIRECTORY=

#It holds the Installation directory of TAP
InstallDir="/usr/bin/$TAP"

#It holds the TAP Registry directory path
REGISTRY_DIRECTORY="/etc/TAP_REGISTRY"

#It holds the TAP common registry file path
COMMON_FILE="$REGISTRY_DIRECTORY/common.txt"
#Identifier forinstallation
INST_TYPE="/etc/TAP_REGISTRY/inst_type"

#It holds the user whose cron entry is to be added
CRON_USER="root"

#It is flag indicating PATH_FOR_CRON_ENTRY is added. If set, PATH_FOR_CRON_ENTRY has proper value 
CRON_FLAG=0

#It holds the path for tcp parameters 
TCP_PARAMETER_PATH="/etc/sysctl.conf"

#It is set only if any kernel parameter is updated in the script
UPDATE_KERNEL_PARAMETER=0

#It holds the setup zip file name which contains all setup files.
#Setup_zip_file="NOW_TAP_CD_"$INSTALLER_VERSION"_SetupFiles.zip"
#output line to be written in registry file
out_line="<configurationFile             data='/etc/TAP_REGISTRY/$BROKER_ID'                                info='This Is The Global TAP Configuration File'/>"

validchoice=""

UPGRADE_FLAG=0

#Flags used to decide whether fresh or upgrade of installation.
RDM_UPGRADE_FLAG=0
MULTI_TAP=0
TCMS_UPGRADE_FLAG=0
RMS_UPGRADE_FLAG=0
DGU_UPGRADE_FLAG=0
TAP_MONITORING_UPGRADE_FLAG=0
UNINSTALLER_UPGRADE_FLAG=0

#Interactive ports for RDM. Previously taken from TAPConfiguration.ini
INTERFACE_THREAD_INTERACTIVE_PORT_RDM=9618
INTERFACE_THREAD_NON_INTERACTIVE_PORT_RDM=9628

#Parameters from the tcp parameter file.
TCP_KEEPALIVE_INTERVAL_PARAM="net.ipv4.tcp_keepalive_intvl"
TCP_KEEPALIVE_TIME_PARAM="net.ipv4.tcp_keepalive_time"
TCP_KEEPALIVE_PROBES_PARAM="net.ipv4.tcp_keepalive_probes"


#Header in the repo config file
PATHS_PARAM=PATHS
NUMBER_OF_LOGS_PARAM=NUMBER_OF_LOGS

#Headers in the tap registry file
ROOT_NAME=ROOT
SECTION_NAME=SECTION
VERSION_NAME=VERSION

#Parameters from the registry file under ROOT header
TAPVERSION_PARAM="TAPVERSION"
VERSION_PARAM="VERSION"
PATH_PARAM="PATH"
# ADDED FOR NORMAL INSTALLER
SERVICESTATUS_PARAM="SERVICESTATUS"

COUNT_PARAM="COUNT"
REPO_CONFIG_FILE_PATH_PARAM="REPO_CONFIG_FILE_PATH"
TCMS_LOG_FILES_PATH_PARAM="TCMS_LOG_FILES_PATH"
CONNECTION_TYPE_PARAM="CONNECTION_TYPE"

#Parameters from the registry file under INDEX header
INTERFACE_THREAD_INTERACTIVE_PORT_PARAM="INTERFACE_THREAD_INTERACTIVE_PORT"
INTERFACE_THREAD_NON_INTERACTIVE_PORT_PARAM="INTERFACE_THREAD_NON_INTERACTIVE_PORT"
CONFIG_FILE_PATH_PARAM="CONFIG_FILE_PATH"
FIX_CONFIG_FILE_PATH_PARAM="FIX_CONFIG_FILE_PATH"
ARGUMENT_PARAM="ARGUMENT"

#Parameters from the registry file under VERSION header
TCMS_IP_VERSION_PARAM=TCMS_IP_VERSION
RMS_VERSION_PARAM=RMS_VERSION
# ADDED FOR NORMAL INSTALLER
TAP_MONITORING_VERSION_PARAM=TAP_MONITORING_VERSION
TAP_STATISTICS_VERSION_PARAM=TAP_STATISTICS_VERSION
DGU_VERSION_PARAM=DGU_VERSION
UNINSTALLER_VERSION_PARAM=UNINSTALLER_VERSION

#Parameters fron the config file
BROKER_ID_PARAM="BROKER_ID"

TAP_MAX_INDEX="8"
TAP_REG_MAX_COUNT=8
TCMS_INDEX="13"
# ADDED FOR NORMAL INSTALLER
TAP_MONITORING_INDEX="9"
TAP_REPO_MAX_INDEX="13"
INSTALLATION_COUNT="0"
CONNECTION_TYPE="0"
Installer_value=1

SetupFilesPath="/tmp/TAP_Setup_Files"
#mkdir -p "/tmp/TAP_Setup_Files"
#SetupFilesPath="/tmp/TAP_Setup_Files"
#if [ ! -d $SetupFilesPath ]; then
#	echo "Cannot create SetupFilesPath directory." | tee -a $LOG
#	exit
#fi

#unzip -o "$Setup_zip_file" -x -d $SetupFilesPath >> $LOG
#value=$?
#if [ $value -ne 0 ]; then
#	echo "Cannot unzip $Setup_zip_file." | tee -a $LOG
#	exit
#fi

echo "All files extracted" >> $LOG

cd "$SetupFilesPath/exe"

chmod -R 777 "$SetupFilesPath" >> $LOG 2>> $LOG
echo "All permissions granted to Setup Files" >> $LOG


Now_Menu_BROKERID() {	

	while true
	do
		echo -e "Please Enter your Broker ID : \c " | tee -a $LOG

		read BROKER_ID
		
		echo $BROKER_ID > $BROKER_ID_FILE
		count=`wc -c $BROKER_ID_FILE | cut -c 1`
		if [ $count -le 6 ];then
			echo "BROKER ID: $BROKER_ID has been accepted." >> $LOG
			break; >>$LOG
		else
			echo "Please enter a valid Broker ID." | tee -a $LOG			
		fi
	done

}


#This funtion is used only for upgradation case of the market defined.
Upgrade_NOWTAP() {
	
	cd $REGISTRY_DIRECTORY
	>$BROKER_ID_FILE	
	ls $REGISTRY_DIRECTORY | grep -v common.txt > $BROKER_ID_TEMP_FILE
	while read line
	do
		count=`cat $line | grep "\[$MARKET_INDEX\]" |wc -l`
		if [ $count -eq 1 ];then
			echo $line >> $BROKER_ID_FILE
		fi		

	done < $BROKER_ID_TEMP_FILE

}



OnExitInstall() {

if [ $# -ne 1 ];then
	echo " Invalid count of params passed OnExitInstall   " >>$LOG
	exit 1
fi		
	param=$1
	#Cleanup activites to be done here
	#rm -Rf "$SetupFilesPath"
	#echo "SetupFiles cleaned up." >> $LOG
	chmod -R 777 $InstallDir >> $LOG 2>> $LOG
#	echo $InstallDir
	cd "$InstallDir"
	cd ..
	InstallDir=`pwd`
	#NOTE: Recursive change permission is removed
	chmod 777 $InstallDir >> $LOG 2>> $LOG
	chmod -R 777 $REGISTRY_DIRECTORY >> $LOG 2>> $LOG

	#Summary Logging of installation.

	if [ $SUCCESS_COUNT -ne 0 ];then

		>/tmp/TAPInstallationSummary.log
		echo "----------------------------------------" > /tmp/TAPInstallationSummary.log
		echo "TAP Installation details:-" >> /tmp/TAPInstallationSummary.log
		echo -e "Successfull Installation Count: $SUCCESS_COUNT	" >> /tmp/TAPInstallationSummary.log
		echo "Following are the brokers installed successfully.." >> /tmp/TAPInstallationSummary.log
		echo -e "$LogBuffer" >> /tmp/TAPInstallationSummary.log
		echo "----------------------------------------" >> /tmp/TAPInstallationSummary.log
		echo "-------------------------------------RDM MARKET END----------------------------------------" | tee -a $LOG 
		echo
	fi

	if [ $param -eq 1 ];then
		
		exit 1
	else
		exit 0
	fi
}


#If the process is running, then it will kill the process
#If the process is not running, then it will return
#If the kill of proces fails, installer will abort
KillProcess() {

	process_name=$1
	value=`ps -C $process_name | grep -v PID | awk '{print $1}'| wc -l`
	if [ $value -gt 0 ]; then
		echo "Trying to kill $process_name process" >> $LOG
		kill -9 `ps -C $process_name | grep -v PID | awk '{print $1}'` >>$LOG 2>>$LOG
		value=$?
		if [ $value -ne 0 ]; then
			echo "Cannot kill $process_name process Return value: $value" | tee -a $LOG
			exit 1
		fi 
		echo "Process $process_name killed successfully" >> $LOG
	fi

	return
}
# Added for normal markets
#If the none tap ond tap_ip_monitoring_service is not running, then it will return
#If the kill of proces fails,installer will abort

KillAllProcess() {
	value=`ps -e | grep tap_ip_*_$BROKER_ID | awk '{print $1}'| wc -l`
	if [ $value -gt 0 ]; then
		echo "Trying to kill all tap_ip processes." >> $LOG
		kill -9 `ps -e | grep tap_ip_*_$BROKER_ID | awk '{print $1}'` >>$LOG 2>>$LOG
		value=$?
		if [ $value -ne 0 ]; then
			echo "Cannot kill all tap_ip processes Return value: $value" | tee -a $LOG
			exit 1
		fi
		echo "Process of all tap and monitoring_service killed successfully" >> $LOG
	fi
	
	return
}

#This function will set the PATH_FOR_CRON_ENTRY variable to proper value based on Federo/Ubuntu
Check_Cron_Path() {
	
	#Check whether cron Daemon is present or not ( cron is file name in Ubuntu and crond in Linux )
	if [[  -f /etc/init.d/cron ||  -f /etc/init.d/crond ]] ;then

		echo "RPM for cron is installed on the server." >>$LOG
		
		#Check whether cron Daemon is up or not in the current server.

		CRON_STATUS=$(ps -e |grep cron |wc -l)
		value=$?

	        if [ $value -ne 0 ]; then
                        
			echo "Cannot able to save the cron status Return value: $value"|tee -a $LOG 
                        AbortInstall
            	fi
		if [ $CRON_STATUS -eq 0 ];then
			
			echo "Cron daemon is not running.Kindly start cron service and reinstall TAP."| tee -a $LOG
			AbortInstall
		
		else
			
			#Check whether installation is on Federo/Ubuntu.
		
			if [ -d "$PATH_FOR_CRON_ENTRY/crontabs" ]; then
				echo "Installing on Ubuntu configuration" >> $LOG
				PATH_FOR_CRON_ENTRY="$PATH_FOR_CRON_ENTRY/crontabs/$CRON_USER"			
		
			else
				echo "Installing on Federo Linux configuration" >> $LOG
				PATH_FOR_CRON_ENTRY="$PATH_FOR_CRON_ENTRY/$CRON_USER"			
		
			fi

				echo "Path of Cron entry file is $PATH_FOR_CRON_ENTRY" >> $LOG

			#Flag is used in AbortInstall and Uninstall, to check whether cron entries are added on the system
				CRON_FLAG=1
				return
		fi
	else
		echo "RPM for crontabs is not installed on server. Kindly install RPM for crontabs and reinstall TAP." | tee -a $LOG
		AbortInstall
	
	fi
}

AbortInstall() {

	if [  $UPGRADE_FLAG -eq 1 ]; then
		
#			   #Cleanup of RDM
				rm -Rf "$InstallDir/TAP_RDM"
				./config_utility -sc $REGISTRY_FILE $MARKET_INDEX
				./config_utility -sd $REPO_CONFIG_FILE $PATHS_PARAM LOG_FILE_PATH_$MARKET_INDEX
				./config_utility -sd $REPO_CONFIG_FILE $PATHS_PARAM REPOSITORY_FILE_PATH_$MARKET_INDEX
				echo "TAP RDM Installation failed." | tee -a $LOG
				OnExitInstall 1

	else
		if [ $MULTI_TAP -eq 0 ];then
		#For normal markets
		#kill the TAP and Monitoring if running
		KillAllProcess

		#END NORMAL MARKET
		fi
		rm -Rf "$InstallDir"
		rm -Rf "$REGISTRY_FILE"
		if [ $CRON_FLAG -eq 1 ]; then
			
			echo "Removing schedular entries" >> $LOG
			echo "Copy of cron entry is kept at /tmp/cron_backup" >> $LOG
			cp -f $PATH_FOR_CRON_ENTRY "/tmp/cron_backup"
			if [ $MULTI_TAP -eq 0 ];then
			# Normal Markets 
			sed -e '/tap_ip_monitoring_service_$BROKER_ID/d' -e '/tap_ip_repository_management_$BROKER_ID/d' $PATH_FOR_CRON_ENTRY > /tmp/new_cron_file.txt			
			#end NORMAL MARKETS
			else
			grep -v -w "tap_ip_repository_management_$BROKER_ID" $PATH_FOR_CRON_ENTRY > /tmp/new_cron_file.txt
			fi
			diff $PATH_FOR_CRON_ENTRY /tmp/new_cron_file.txt >> $LOG
			cp -f /tmp/new_cron_file.txt $PATH_FOR_CRON_ENTRY
			value=$?
			if [ $value -ne 0 ]; then
				echo "Copy of /tmp/new_cron_file.txt to the $PATH_FOR_CRON_ENTRY failed: Return value: $value" | tee -a $LOG
				echo "Reverting back /tmp/cron_backup to $PATH_FOR_CRON_ENTRY" | tee -a $LOG
				cp -f /tmp/cron_backup $PATH_FOR_CRON_ENTRY >> $LOG
				echo "TAP Cleanup failed." | tee -a $LOG
				exit 1

			fi

		fi		
		
		echo "TAP Installation failed." | tee -a $LOG
		OnExitInstall 1
	fi	
}

#It does the entry of tcp parameters
RegEntry() {

	#Reading TCP_KEEPALIVE_INTERVAL from the TCP_PARAMETER_PATH
	./config_utility -g $TCP_PARAMETER_PATH $TCP_KEEPALIVE_INTERVAL_PARAM
	value=$?
	if [ $value -ne 0 ]; then

		#Writing TCP_KEEPALIVE_INTERVAL in the TCP_PARAMETER_PATH
		./config_utility -a $TCP_PARAMETER_PATH $TCP_KEEPALIVE_INTERVAL_PARAM $KEEP_ALIVE_INTERVAL
		value=$?
		if [ $value -ne 1 ]; then
			echo "Cannot write $TCP_KEEPALIVE_INTERVAL_PARAM to the $TCP_PARAMETER_PATH. Return value: $value" | tee -a $LOG
			AbortInstall
		fi
		UPDATE_KERNEL_PARAMETER=1
		
	else
		#Update case		
		export registry_value=`cat tap_val.txt`
		echo "$TCP_KEEPALIVE_INTERVAL_PARAM in $TCP_PARAMETER_PATH is: $registry_value" >> $LOG		
		
		if [ $registry_value -ne $KEEP_ALIVE_INTERVAL ]; then
			
			./config_utility -m $TCP_PARAMETER_PATH $TCP_KEEPALIVE_INTERVAL_PARAM $KEEP_ALIVE_INTERVAL
			value=$?
			if [ $value -ne 1 ]; then
				echo "Cannot write $TCP_KEEPALIVE_INTERVAL_PARAM to the $TCP_PARAMETER_PATH. Return value: $value" | tee -a $LOG
				AbortInstall
			fi
			UPDATE_KERNEL_PARAMETER=1
		fi

	fi


	#Reading TCP_KEEPALIVE_TIME from the TCP_PARAMETER_PATH
	./config_utility -g $TCP_PARAMETER_PATH $TCP_KEEPALIVE_TIME_PARAM
	value=$?
	if [ $value -ne 0 ]; then

		#Writing TCP_KEEPALIVE_TIME in the TCP_PARAMETER_PATH
		./config_utility -a $TCP_PARAMETER_PATH $TCP_KEEPALIVE_TIME_PARAM $KEEP_ALIVE_TIME
		value=$?
		if [ $value -ne 1 ]; then
			echo "Cannot write $TCP_KEEPALIVE_TIME_PARAM to the $TCP_PARAMETER_PATH. Return value: $value" | tee -a $LOG
			AbortInstall
		fi
		UPDATE_KERNEL_PARAMETER=1
		
	else
		#Update case		
		export registry_value=`cat tap_val.txt`
		echo "$TCP_KEEPALIVE_TIME_PARAM in $TCP_PARAMETER_PATH is: $registry_value" >> $LOG		
		
		if [ $registry_value -ne $KEEP_ALIVE_TIME ]; then
			
			./config_utility -m $TCP_PARAMETER_PATH $TCP_KEEPALIVE_TIME_PARAM $KEEP_ALIVE_TIME
			value=$?
			if [ $value -ne 1 ]; then
				echo "Cannot write $TCP_KEEPALIVE_TIME_PARAM to the $TCP_PARAMETER_PATH. Return value: $value" | tee -a $LOG
				AbortInstall
			fi
			UPDATE_KERNEL_PARAMETER=1
		fi

	fi



	#Reading TCP_KEEPALIVE_PROBES from the TCP_PARAMETER_PATH
	./config_utility -g $TCP_PARAMETER_PATH $TCP_KEEPALIVE_PROBES_PARAM
	value=$?
	if [ $value -ne 0 ]; then

		#Writing TCP_KEEPALIVE_PROBES in the TCP_PARAMETER_PATH
		./config_utility -a $TCP_PARAMETER_PATH $TCP_KEEPALIVE_PROBES_PARAM $TCP_KEEPALIVE_PROBES
		value=$?
		if [ $value -ne 1 ]; then
			echo "Cannot write $TCP_KEEPALIVE_PROBES_PARAM to the $TCP_PARAMETER_PATH. Return value: $value" | tee -a $LOG
			AbortInstall
		fi
		UPDATE_KERNEL_PARAMETER=1
		
	else
		#Update case		
		export registry_value=`cat tap_val.txt`
		echo "$TCP_KEEPALIVE_PROBES_PARAM in $TCP_PARAMETER_PATH is: $registry_value" >> $LOG		
		
		if [ $registry_value -ne $TCP_KEEPALIVE_PROBES ]; then
			
			./config_utility -m $TCP_PARAMETER_PATH $TCP_KEEPALIVE_PROBES_PARAM $TCP_KEEPALIVE_PROBES
			value=$?
			if [ $value -ne 1 ]; then
				echo "Cannot write $TCP_KEEPALIVE_PROBES_PARAM to the $TCP_PARAMETER_PATH. Return value: $value" | tee -a $LOG
				AbortInstall
			fi
			UPDATE_KERNEL_PARAMETER=1
		fi

	fi

	if [ $UPDATE_KERNEL_PARAMETER -eq 1 ]; then
		#Upgrading the kernel parameters
		echo "Upgrading the kernel parameters" >> $LOG
		/sbin/sysctl -p >> $LOG
		value=$?
		if [ $value -ne 0 ]; then
			echo "Upgradation of kernel parameter values failed. Return value: $value" | tee -a $LOG
			AbortInstall
		fi

	fi

}


#Kindly ensure the first operand is from the script.
FractiontoInteger() {
	a=$1
	b=$2

	a1=`echo $1|cut -d. -f1`
	#echo  a1 is $a1

	b1=`echo $2|cut -d. -f1`
	#echo b1 is $b1
	if [ $a1 -gt $b1 ]; then
        	#echo $1 is greater than $2
		return 1
	elif [ $a1 -lt $b1 ]; then
        	#echo $1 is less than $2
		return 2
	else
        	a2=`echo $1|cut -d. -f2`
	        #echo a2 is $a2
        	b2=`echo $2|cut -d. -f2`
        	#echo b2 is $b2

        	if [ $a2 -gt $b2 ]; then
                	#echo $1 is greater than $2
			return 1
        	elif [ $a2 -lt $b2 ]; then
                	#echo $1 is less than $2
			return 2
        	else
                	#echo $1 is equal to $2
			return 2
	       	fi

	fi

}

FractiontoIntegerNew() {
	a=$1
	b=$2

	a1=`echo $1|cut -d. -f1`
	#echo  a1 is $a1

	b1=`echo $2|cut -d. -f1`
	#echo b1 is $b1
	
	if [ $b1 -gt 7 ]; then
		return 3
	fi

	if [ $a1 -gt $b1 ]; then
        	#echo $1 is greater than $2
		return 1
	elif [ $a1 -lt $b1 ]; then
        	#echo $1 is less than $2
		return 2
	else
        	a2=`echo $1|cut -d. -f2`
	        #echo a2 is $a2
        	b2=`echo $2|cut -d. -f2`
        	#echo b2 is $b2

        	if [ $a2 -gt $b2 ]; then
                	#echo $1 is greater than $2
			return 1
        	elif [ $a2 -lt $b2 ]; then
                	#echo $1 is less than $2
			return 2
        	else
                	#echo $1 is equal to $2
			return 2
	       	fi

	fi

}

SetInstalledVersion() {

	case "$CURRENT_MARKET_INDEX"
	in

                8)      #RDM version check
                        if [ $MARKET_INDEX -ne $CURRENT_MARKET_INDEX ]; then
                                return
                        fi

                         #Read the RDM_VERSION from registry file
                        ./config_utility -sg $REGISTRY_FILE $MARKET_INDEX $VERSION_PARAM
                        value=$?
                        if [ $value -ne 0 ]; then
                                echo "Reading of RDM VERSION failed. Return value: $value" | tee -a $LOG
                                AbortInstall
                        fi

                        export registry_value=`cat tap_val.txt`
                        echo "TAP RDM Version installed is: $registry_value" >> $LOG
                        # FractiontoInteger $TAP_RDM_VER $registry_value
                        # value=$?
                        # if [ $value -eq 2 ]; then
                                # echo "You have already latest TAP RDM [Ver.$INSTALLER_VERSION]." | tee -a $LOG
                                # OnExitInstall 0
                        # fi
                        FractiontoIntegerNew $TAP_RDM_VER $registry_value
                        value=$?
                        if [ $value -eq 3 ]; then
                                echo -e "\nNormal TAP RDM $TAP_RDM_VER cannot be upgraded for existing TAP for BROKER_ID:- $BROKER_ID ."  >> $LOG
                                Installer_value=$value
								return
                        fi
						
                        if [ $value -eq 2 ]; then
                                echo -e "\nYou have already latest TAP RDM [Ver.$registry_value] for BROKER_ID:- $BROKER_ID ." | tee -a $LOG
                                Installer_value=$value
								return
                        fi							
                        RDM_UPGRADE_FLAG=1
						Installer_value=1
                        ;;


                13)      #TCMS version check

                         #Read the TCMS_VERSION from registry file
                        ./config_utility -sg $REGISTRY_FILE $VERSION_PARAM $TCMS_IP_VERSION_PARAM
                        value=$?
                        if [ $value -ne 0 ]; then
                                TCMS_UPGRADE_FLAG=1
                                return
                        fi

                        export registry_value=`cat tap_val.txt`
                        echo "TCMS Version installed is: $registry_value" >> $LOG
                        FractiontoInteger $TCMS_IP_VER $registry_value
                        value=$?
                        if [ $value -eq 2 ]; then
                                echo "You have latest TCMS installed." >> $LOG
                                TCMS_UPGRADE_FLAG=2
				return
                        fi
                        TCMS_UPGRADE_FLAG=1
                        ;;


	        9)      #RMS version check

                         #Read the RMS_VERSION from registry file
                        ./config_utility -sg $REGISTRY_FILE $VERSION_PARAM $RMS_VERSION_PARAM
                        value=$?
                        if [ $value -ne 0 ]; then
                                RMS_UPGRADE_FLAG=1
                                return
                        fi

                        export registry_value=`cat tap_val.txt`
                        echo "RMS Version installed is: $registry_value" >> $LOG
                        FractiontoInteger $RMS_VER $registry_value
                        value=$?
                        if [ $value -eq 2 ]; then
                                echo "You have latest RMS installed." >> $LOG
                                RMS_UPGRADE_FLAG=2
				return
                        fi
                        RMS_UPGRADE_FLAG=1
                        ;;
		10)		if [ $MULTI_TAP -eq 0 ]; then
				# Check only for normal markets 
                      #TAP_MONITORING version check

                         #Read the TAP_MONITORING_VERSION from registry file
                        ./config_utility -sg $REGISTRY_FILE $VERSION_PARAM $TAP_MONITORING_VERSION_PARAM
                        value=$?
                        if [ $value -ne 0 ]; then
                                TAP_MONITORING_UPGRADE_FLAG=1
                                return
                        fi

                        export registry_value=`cat tap_val.txt`
                        echo "TAP_MONITORING Version installed is: $registry_value" >> $LOG
                        FractiontoInteger $TAP_MONITORING_VER $registry_value
                        value=$?
                        if [ $value -eq 2 ]; then
                                echo "You have latest TAP_MONITORING installed." >> $LOG
                                TAP_MONITORING_UPGRADE_FLAG=2
				return
                        fi
                        TAP_MONITORING_UPGRADE_FLAG=1
			#end check for normal markets 
			fi
                        ;;
		11)      #DGU version check

                         #Read the DGU_VERSION from registry file
                        ./config_utility -sg $REGISTRY_FILE $VERSION_PARAM $DGU_VERSION_PARAM
                        value=$?
                        if [ $value -ne 0 ]; then
                                DGU_UPGRADE_FLAG=1
                                return
                        fi

                        export registry_value=`cat tap_val.txt`
                        echo "DGU Version installed is: $registry_value" >> $LOG
                        FractiontoInteger $DGU_VER $registry_value
                        value=$?
                        if [ $value -eq 2 ]; then
                                echo "You have latest DGU installed." >> $LOG
                                DGU_UPGRADE_FLAG=2
				return
                        fi
                        DGU_UPGRADE_FLAG=1
                        ;;


                12)      #Uninstaller version check

                         #Read the UNINSTALLER_VERSION from registry file
                        ./config_utility -sg $REGISTRY_FILE $VERSION_PARAM $UNINSTALLER_VERSION_PARAM
                        value=$?
                        if [ $value -ne 0 ]; then
                                UNINSTALLER_UPGRADE_FLAG=1
                                return
                        fi

                        export registry_value=`cat tap_val.txt`
                        echo "UNINSTALLER Version installed is: $registry_value" >> $LOG
                        FractiontoInteger $UNINSTALLER_VER $registry_value
                        value=$?
                        if [ $value -eq 2 ]; then
                                echo "You have latest UNINSTALLER installed." >> $LOG
                                UNINSTALLER_UPGRADE_FLAG=2
				return
                        fi
                        UNINSTALLER_UPGRADE_FLAG=1
                        ;;


		*)	echo "In SetInstalledVersion: Default case" >> $LOG
			OnExitInstall 0
			;;

	esac

}



OnInit() {

	Index=$1
	if [ $Index -eq 0 ]; then
		echo "Market Index not defined." | tee -a $LOG
		exit 1
	fi
	cd "$SetupFilesPath/exe"

	chmod -R 777 "$SetupFilesPath" >> $LOG 2>> $LOG

	#Checking for REGISTRY_DIRECTORY if present.
	if [ ! -d $REGISTRY_DIRECTORY ]; then
		UPGRADE_FLAG=0
		echo "Creating $REGISTRY_DIRECTORY directory" >> $LOG
		mkdir $REGISTRY_DIRECTORY
		value=$?
		if [ $value -ne 0 ]; then
			echo "Creation of $REGISTRY_DIRECTORY directory failed. Return value: $value" | tee -a $LOG
			AbortInstall
		fi

		if [ $MULTI_TAP -eq 1 ]; then
			echo "Creating of inst_type file in registry " >>$LOG
			touch $INST_TYPE
			echo "m" >$INST_TYPE
			value=$?
			if [ $value -ne 0 ]; then
				echo "Creation of inst_type file failed .Return value :$value " | tee -a $LOG
				AbortInstall
			fi
		fi
		
		# the registry common file.
		if [ ! -f $COMMON_FILE ]; then
                        echo "Creating $COMMON_FILE file" >> $LOG
                        touch "$COMMON_FILE"			
			value=$?
                        if [ $value -ne 0 ]; then
                                echo "Creation of $COMMON_FILE file failed. Return value: $value" | tee -a $LOG
                                AbortInstall
                        fi			
                fi

		#Writing of PATH in the registry common file
		 echo "Writing of PATH in the registry common file" >> $LOG
		 ./config_utility -sa $COMMON_FILE $ROOT_NAME $PATH_PARAM "$InstallDir"		 
		 value=$?
		 if [ $value -ne 1 ]; then
			echo "Cannot write $PATH_PARAM to the registry common file. Return value: $value" | tee -a $LOG
			AbortInstall
		 fi

		 #Writing of COUNT of number of brokers installed in the registry common file
		echo "Writing of COUNT in the registry common file" >> $LOG
                ./config_utility -sa $COMMON_FILE $ROOT_NAME $COUNT_PARAM 0
		value=$?
		if [ $value -ne 1 ]; then
			echo "Cannot write $COUNT_PARAM to the registry common file. Return value: $value" | tee -a $LOG
			AbortInstall
		fi

	fi

	if [ ! -f $COMMON_FILE ]; then
		echo "TAP common registry file not present." >> $LOG
		AbortInstall
	fi

	#It holds the registry file path of broker to be installed.
	REGISTRY_FILE="$REGISTRY_DIRECTORY/$BROKER_ID"

	if [ ! -f $REGISTRY_FILE ]; then
		echo "TAP registry file not present for Broker ID: [$BROKER_ID]." >> $LOG
		UPGRADE_FLAG=0
		INSTALLATION_COUNT=1
		
		InstallDir="$InstallDir/$BROKER_ID"
		echo "TAP Installation directory for Broker ID [$BROKER_ID] : $InstallDir" >> $LOG
		return
	else
		INSTALLATION_COUNT=0
	fi

	#Read the TAP path if present
	./config_utility -sg $REGISTRY_FILE $ROOT_NAME $PATH_PARAM
	value=$?		
        if [ $value -ne 0 ]; then
		echo "Reading of TAP PATH failed. Return value: $value" | tee -a $LOG
		AbortInstall
	fi

	export InstallDir=`cat tap_val.txt`
        #echo "TAP is installed at: $InstallDir" | tee -a $LOG
		
	if [ ! -d $InstallDir ]; then
		UPGRADE_FLAG=0
		echo "TAP installed directory not present. Return value: $value" | tee -a $LOG
		AbortInstall
		
	else
		if [ ! -d $InstallDir/TAP_COMMON ]; then
			UPGRADE_FLAG=0
			echo "TAP_COMMON directory not present. Return value: $value " | tee -a $LOG
			AbortInstall
		fi	
		
		UPGRADE_FLAG=1
		
		echo "Setup files path: $SetupFilesPath" >> $LOG

		cp -pf "$SetupFilesPath/exe/config_utility" "$InstallDir/TAP_COMMON"
		value=$?
		if [ $value -ne 0 ]; then 
			echo "Copying of config_utility failed. Return value: $value" | tee -a $LOG
			AbortInstall
		fi

		cd "$InstallDir/TAP_COMMON"
		
		#TAPVERSION check commented for time being

		#echo "REGISTRY_FILE : $REGISTRY_FILE"
		#echo "ROOT_NAME : $ROOT_NAME"
		#echo "TAP_VERSION_PARAM : $TAPVERSION_PARAM"
	
		#Read the TAP_VERSION from registry file
		#./config_utility -sg $REGISTRY_FILE $ROOT_NAME $TAPVERSION_PARAM
		#value=$?		
                #if [ $value -ne 0 ]; then
	        #        echo "Reading of TAPVERSION failed"
                #        AbortInstall
         	#fi

		#export registry_value=`cat tap_val.txt`
		#echo "TAP version installed is: $registry_value"
		#FractiontoInteger $PRODUCT_VERSION $registry_value
		#value=$?
		#if [ $value -eq 2 ]; then
		#	echo "You have latest TAP installed."
		#	OnExitInstall
		#fi
			
			  #echo "In RDM version check"
                ./config_utility -sg $REGISTRY_FILE 8 $PATH_PARAM
                value=$?
                if [ $value -eq 0 ]; then
                        CURRENT_MARKET_INDEX=8
                        SetInstalledVersion $CURRENT_MARKET_INDEX
						if [ $Installer_value -ne 1 ]; then
							echo "Not upgrading TAP RDM for $BROKER_ID ::ONinit" >> $LOG
							return
						fi	
                fi

  		#TCMS version check
                CURRENT_MARKET_INDEX=13
                SetInstalledVersion $CURRENT_MARKET_INDEX

		#RMS version check
                CURRENT_MARKET_INDEX=9
                SetInstalledVersion $CURRENT_MARKET_INDEX
		if [ $MULTI_TAP -eq 0 ]; then
		#TAP_MONITORING version check #Normal Markets
                CURRENT_MARKET_INDEX=10
                SetInstalledVersion $CURRENT_MARKET_INDEX
		#End Normal Markets
		fi
                #DGU_VER version check
                CURRENT_MARKET_INDEX=11
                SetInstalledVersion $CURRENT_MARKET_INDEX

                #UNINSTALLER version check
                CURRENT_MARKET_INDEX=12
                SetInstalledVersion $CURRENT_MARKET_INDEX			

		if [ $MULTI_TAP -eq 0 ]; then
		# Normal Markets Code
		#Writing of SERVICESTATUS in the registry file
		#Set the service status flag in the registry. This is required to inform
		#TAP monitoring service about the installation being in progress.

		echo "Writing of SERVICESTATUS in the registry file" >> $LOG
                ./config_utility -sa $REGISTRY_FILE $ROOT_NAME $SERVICESTATUS_PARAM 1
		value=$?
		if [ $value -ne 1 ]; then
			echo "Cannot write SERVICESTATUS to the registry file. Return value: $value" | tee -a $LOG
			AbortInstall
		fi	
		#End Code NORMAL MARKETS
		fi
	fi
	
}

PreInstall() {

	REPO_CONFIG_FILE="$InstallDir/TAP_REPO_MANAGEMENT/CONFIG/tap_repo.ini"
	STATS_CONFIG_FILE="$InstallDir/TAP_STATISTICS/CONFIG/tap_statistics.ini"

	#Command to be added in the cron
        TASK_COMMAND_REPO="\"$InstallDir/TAP_REPO_MANAGEMENT/BIN/tap_ip_repository_management_$BROKER_ID\" -c \"../CONFIG/tap_repo.ini\" -w \"$InstallDir/TAP_REPO_MANAGEMENT/BIN\""
	if [ $MULTI_TAP -eq 0 ];then
	#NORMAL MARKETS
	TASK_COMMAND_MONITORING="\"$InstallDir/TAP_MONITORING/BIN/tap_ip_monitoring_service_$BROKER_ID\" -c \"$InstallDir/TAP_MONITORING/CONFIG/tap_monitoring_$BROKER_ID\""
	#END_NORMAL MARKET
	fi
        RDM_CONFIG_FILE="$InstallDir/TAP_RDM/CONFIG/tap_rdm.ini"
        
	echo "Member ID: "\[$BROKER_ID\]"" | tee -a $LOG

	if [ $UPGRADE_FLAG -eq 0 ]; then

		#Install all the common tools
		if [ ! -d "$InstallDir" ]; then
			echo "Creating $InstallDir" >> $LOG
			mkdir -p $InstallDir
			value=$?
			if [ $value -ne 0 ]; then 
				echo "Creation of $InstallDir directory failed. Return value: $value" | tee -a $LOG
				AbortInstall
			fi		
		fi
		#FOR TESTING
		chmod -R 777 $InstallDir >> $LOG 2>> $LOG
		echo "All permissions granted" >> $LOG

		if [ ! -d "$InstallDir/TAP_COMMON" ]; then
			echo "Creating $InstallDir/TAP_COMMON" >> $LOG
			mkdir $InstallDir/TAP_COMMON			
			value=$?
                        if [ $value -ne 0 ]; then
                                echo "Creation of $InstallDir/TAP_COMMON directory failed. Return value: $value" | tee -a $LOG
                                AbortInstall
                        fi
		fi	
		if [ $MULTI_TAP -eq 0 ]; then
		#NORMAL MARKET SERVICE INSTALLATION				
		#Installation of Monitoring service
		if [ ! -d "$InstallDir/TAP_MONITORING/BIN" ]; then
			echo "Creating $InstallDir/TAP_MONITORING/BIN directory" >> $LOG
			mkdir -p $InstallDir/TAP_MONITORING/BIN
			value=$?	
			if [ $value -ne 0 ]; then
                                echo "Creation of $InstallDir/TAP_MONITORING/BIN directory failed. Return value: $value" | tee -a $LOG
                                AbortInstall
                        fi
		fi
		
		echo "Copying tap_ip_monitoring_service" >> $LOG
		cp -u "$SetupFilesPath/exe/tap_ip_monitoring_service" "$InstallDir/TAP_MONITORING/BIN/tap_ip_monitoring_service_$BROKER_ID"
		value=$?
		if [ $value -ne 0 ]; then
			echo "Copying of tap_ip_monitoring_service_$BROKER_ID failed. Return value: $value" | tee -a $LOG
                        AbortInstall
                fi
                
		if [ ! -d "$InstallDir/TAP_MONITORING/CONFIG" ]; then
                        echo "Creating $InstallDir/TAP_MONITORING/CONFIG directory" >> $LOG
                        mkdir $InstallDir/TAP_MONITORING/CONFIG
			value=$?
                        if [ $value -ne 0 ]; then
                                echo "Creation of $InstallDir/TAP_MONITORING/CONFIG directory failed. Return value: $value" | tee -a $LOG
                                AbortInstall
                        fi
                fi

		echo "Copying monitoring service configuration file" >> $LOG

        cp -u "$SetupFilesPath/config/tap_monitoring" "$InstallDir/TAP_MONITORING/CONFIG/"
		value=$?
		if [ $value -ne 0 ]; then
               		 echo "Copying of monitoring service configuration file failed. Return value: $value" | tee -a $LOG
                         AbortInstall
        fi
		out_line="<configurationFile             data='/etc/TAP_REGISTRY/$BROKER_ID'                                info='This Is The Global TAP Configuration File'/>"

		> "$InstallDir/TAP_MONITORING/CONFIG/tap_monitoring_$BROKER_ID"
		while read line;do

			case $line in

			     *etc*)
				    echo -e "$out_line" >> "$InstallDir/TAP_MONITORING/CONFIG/tap_monitoring_$BROKER_ID"
					value=$?
					if [ $value -ne 0 ]; then
					     echo "Modifying of tap monitoring service config file failed. Return value: $value" | tee -a $LOG
						 AbortInstall
					fi               
				;;
				*)
					printf "%s\n" "$line" >> "$InstallDir/TAP_MONITORING/CONFIG/tap_monitoring_$BROKER_ID"
                ;;
			esac
		done < "$InstallDir/TAP_MONITORING/CONFIG/tap_monitoring"

		rm -f "$InstallDir/TAP_MONITORING/CONFIG/tap_monitoring"

		echo "Copying shell script to run monitoring service in $Installdir" >> $LOG
		cp -u "$SetupFilesPath/config/run_tap_monitoring.sh" "$InstallDir/run_tap_monitoring_$BROKER_ID.sh"
		value=$?
		if [ $value -ne 0 ]; then
               		 echo "Copying of shell script to run tap monitoring service failed. Return value: $value" | tee -a $LOG
                         AbortInstall
                fi
		
		echo "./TAP_MONITORING/BIN/tap_ip_monitoring_service_$BROKER_ID -c ./TAP_MONITORING/CONFIG/tap_monitoring_$BROKER_ID &">"$InstallDir/run_tap_monitoring_$BROKER_ID.sh"
		value=$?
		if [ $value -ne 0 ]; then
          echo "Modifying of shell script to run tap monitoring service failed. Return value: $value" | tee -a $LOG
          AbortInstall
        fi
		if [ ! -d "$InstallDir/TAP_MONITORING/LOGS" ]; then
                        echo "Creating $InstallDir/TAP_MONITORING/LOGS directory" >> $LOG
                        mkdir $InstallDir/TAP_MONITORING/LOGS
			value=$?
                        if [ $value -ne 0 ]; then
                                echo "Creation of $InstallDir/TAP_MONITORING/LOGS directory failed. Return value: $value" | tee -a $LOG
                                AbortInstall
                        fi
                fi

		if [ ! -d "$InstallDir/TAP_MONITORING/REPOSITORY" ]; then
                        echo "Creating $InstallDir/TAP_MONITORING/REPOSITORY directory" >> $LOG
                        mkdir $InstallDir/TAP_MONITORING/REPOSITORY
			value=$?
                        if [ $value -ne 0 ]; then
                                echo "Creation of $InstallDir/TAP_MONITORING/REPOSITORY directory failed. Return value: $value" | tee -a $LOG
                                AbortInstall
                        fi
                fi

		echo "Details of the Components installed\upgraded successfully.." | tee -a $LOG
		echo "TAP Monitoring Service installed." | tee -a $LOG

		#End Normal Markets.	
		fi
		#Installation of Repository Management
                if [ ! -d "$InstallDir/TAP_REPO_MANAGEMENT/BIN" ]; then
                        echo "Creating $InstallDir/TAP_REPO_MANAGEMENT/BIN directory" >> $LOG
                        mkdir -p $InstallDir/TAP_REPO_MANAGEMENT/BIN
			value=$?
                        if [ $value -ne 0 ]; then
                                echo "Creation of $InstallDir/TAP_REPO_MANAGEMENT/BIN directory failed. Return value: $value" | tee -a $LOG
                                AbortInstall
                        fi
                fi

		echo "Copying repository management" >> $LOG
                cp -u "$SetupFilesPath/exe/tap_ip_repository_management" "$InstallDir/TAP_REPO_MANAGEMENT/BIN/tap_ip_repository_management_$BROKER_ID"
		value=$?
                if [ $value -ne 0 ]; then
			echo "Copying of repository management failed. Return value: $value" | tee -a $LOG
                        AbortInstall
                fi
		
                if [ ! -d "$InstallDir/TAP_REPO_MANAGEMENT/CONFIG" ]; then
                        echo "Creating $InstallDir/TAP_REPO_MANAGEMENT/CONFIG directory" >> $LOG
                        mkdir $InstallDir/TAP_REPO_MANAGEMENT/CONFIG
			value=$?
                        if [ $value -ne 0 ]; then
                                echo "Creation of $InstallDir/TAP_REPO_MANAGEMENT/CONFIG directory failed. Return value: $value" | tee -a $LOG
                                AbortInstall
                        fi
                fi

                echo "Copying repository management configuration file" >> $LOG
                cp -u "$SetupFilesPath/config/tap_repo.ini" "$InstallDir/TAP_REPO_MANAGEMENT/CONFIG"
		value=$?
                if [ $value -ne 0 ]; then
			echo "Copying of repository management configuration file failed. Return value: $value" | tee -a $LOG
                        AbortInstall
                fi

		if [ ! -d "$InstallDir/TAP_REPO_MANAGEMENT/LOGS" ]; then
                        echo "Creating $InstallDir/TAP_REPO_MANAGEMENT/LOGS directory" >> $LOG
                        mkdir $InstallDir/TAP_REPO_MANAGEMENT/LOGS
			value=$?
                        if [ $value -ne 0 ]; then
                                echo "Creation of $InstallDir/TAP_REPO_MANAGEMENT/LOGS directory failed. Return value: $value" | tee -a $LOG
                                AbortInstall
                        fi
                fi

		echo "Details of the Components installed\upgraded successfully.." | tee -a $LOG
		echo "TAP Repository Management installed." | tee -a $LOG
				
		#Installation of TCMS
                if [ ! -d "$InstallDir/TCMS/BIN" ]; then
                        echo "Creating $InstallDir/TCMS/BIN directory" >> $LOG
                        mkdir -p $InstallDir/TCMS/BIN
			value=$?
                        if [ $value -ne 0 ]; then
                                echo "Creation of $InstallDir/TCMS/BIN directory failed. Return value: $value" | tee -a $LOG
                                AbortInstall
                        fi
                fi

               	echo "Copying tcms_ip" >> $LOG
		cp -u "$SetupFilesPath/exe/tcms_ip" "$InstallDir/TCMS/BIN"
		value=$?
                if [ $value -ne 0 ]; then
                	echo "Copying of tcms_ip failed. Return value: $value" | tee -a $LOG
                        AbortInstall
                fi
#NOW MARKET ONKY

		echo "Copying shell script to start TAP in $InstallDir/TCMS/BIN" >> $LOG
		cp -u "$SetupFilesPath/exe/start_tap.sh" "$InstallDir/TCMS/BIN"
		value=$?
		if [ $value -ne 0 ]; then
               		 echo "Copying of shell script to start TAP failed. Return value: $value" | tee -a $LOG
                         AbortInstall
                fi


		echo "Creating run_tap.sh script in $InstallDir/TCMS/BIN directory" >> $LOG
		echo "cd $InstallDir/TCMS/BIN" > "$InstallDir/TCMS/BIN/run_tap.sh"
		echo "$InstallDir/TCMS/BIN/start_tap.sh $BROKER_ID" >> "$InstallDir/TCMS/BIN/run_tap.sh"
		value=$?
		if [ $value -ne 0 ]; then
			echo "Creation of run_tap.sh in $InstallDir/TCMS/BIN failed. Return value: $value" | tee -a $LOG
                        AbortInstall
                fi

		echo "Creating run_tcms.sh script in $InstallDir/TCMS/BIN directory" >> $LOG
		echo "cd $InstallDir/TCMS/BIN" > "$InstallDir/TCMS/BIN/run_tcms.sh"
		echo "$InstallDir/TCMS/BIN/tcms_ip -b $BROKER_ID" >> "$InstallDir/TCMS/BIN/run_tcms.sh"
		value=$?
		if [ $value -ne 0 ]; then
			echo "Creation of run_tcms.sh in $InstallDir/TCMS/BIN failed. Return value: $value" | tee -a $LOG
                        AbortInstall
                fi
#NOW ONLY END
		
		if [ ! -d "$InstallDir/TCMS/LOGS" ]; then
                        echo "Creating $InstallDir/TCMS/LOGS directory" >> $LOG
                        mkdir $InstallDir/TCMS/LOGS
			value=$?
                        if [ $value -ne 0 ]; then
                                echo "Creation of $InstallDir/TCMS/LOGS directory failed. Return value: $value" | tee -a $LOG
                                AbortInstall
                        fi
                fi

                if [ ! -d "$InstallDir/TCMS/REPOSITORY" ]; then
                        echo "Creating $InstallDir/TCMS/REPOSITORY directory" >> $LOG
                        mkdir $InstallDir/TCMS/REPOSITORY
			value=$?
                        if [ $value -ne 0 ]; then
                                echo "Creation of $InstallDir/TCMS/REPOSITORY directory failed. Return value: $value" | tee -a $LOG
                                AbortInstall
                        fi
                fi

		
		#Shortcut creation of tcms in Install directory.
		echo "Creating shortcut for tcms in $InstallDir directory" >> $LOG
		ln -st "$InstallDir" "$InstallDir/TCMS/BIN/run_tcms.sh" >> $LOG
		value=$?
		if [ $value -ne 0 ]; then
			echo "Creation of shortcut for TCMS failed. Return value: $value" | tee -a $LOG
                        AbortInstall
                fi
		
#NOW ONLY
		#Shortcut creation of run_tap.sh in InstallDir directory.
		echo "Creating shortcut for run_tap.sh in $InstallDir directory" >> $LOG
		ln -st "$InstallDir" "$InstallDir/TCMS/BIN/run_tap.sh" >> $LOG
		value=$?
		if [ $value -ne 0 ]; then
			echo "Creation of shortcut for run_tap.sh in $InstallDir failed. Return value: $value" | tee -a $LOG
                        AbortInstall
                fi
#END NOW ONLY
		
                echo "TAP Configuration and Monitoring System installed." | tee -a $LOG

		#Installation of Data Gathering Utility
		if [ ! -d "$InstallDir/TAP_DGU/BIN" ]; then
                        echo "Creating $InstallDir/TAP_DGU/BIN directory" >> $LOG
                        mkdir -p $InstallDir/TAP_DGU/BIN
			value=$?
                        if [ $value -ne 0 ]; then
                                echo "Creation of $InstallDir/TAP_DGU/BIN directory failed. Return value: $value" | tee -a $LOG
                                AbortInstall
                        fi
                fi

                echo "Copying tap_ip_dgu.sh" >> $LOG
		cp -u "$SetupFilesPath/exe/tap_ip_dgu.sh" "$InstallDir/TAP_DGU/BIN"
		value=$?
                if [ $value -ne 0 ]; then
                        echo "Copying of tap_ip_dgu.sh failed. Return value: $value" | tee -a $LOG
                        AbortInstall
                fi

		#Shortcut creation of tap_ip_dgu in Install directory.
		echo "Creating shortcut for dgu in Install directory" >> $LOG
		ln -st "$InstallDir" "$InstallDir/TAP_DGU/BIN/tap_ip_dgu.sh" >> $LOG
		value=$?
		if [ $value -ne 0 ]; then
			echo "Creation of shortcut for DGU failed. Return value: $value" | tee -a $LOG
                        AbortInstall
                fi
                  
		echo "Data Gathering Utility installed." | tee -a $LOG

		#Installation of Uninstaller
		echo "Copying uninstall.sh" >> $LOG
		cp -u "$SetupFilesPath/exe/uninstall.sh" "$InstallDir"
		value=$?
		if [ $value -ne 0 ]; then
                        echo "Copying of uninstall.sh failed. Return value: $value" | tee -a $LOG
                        AbortInstall
                fi

		REGISTRY_FILE="$REGISTRY_DIRECTORY/$BROKER_ID"

		#Making the registry file entries.
		if [ ! -f $REGISTRY_FILE ]; then
                        echo "Creating registry file at $REGISTRY_FILE path" >> $LOG
                        touch "$REGISTRY_FILE"			
			value=$?
                        if [ $value -ne 0 ]; then
                                echo "Creation of $REGISTRY_FILE registry file failed. Return value: $value" | tee -a $LOG
                                AbortInstall
                        fi			
                fi		
		
		#Changing directory to TAP_COMMON
		cd "$InstallDir/TAP_COMMON"
		value=$?
                if [ $value -ne 0 ]; then
                	echo "Changinig directory to TAP_COMMON failed. Return value: $value" | tee -a $LOG
                        AbortInstall
                fi

               	echo "Copying config_utility" >> $LOG
		cp -u "$SetupFilesPath/exe/config_utility" "$InstallDir/TAP_COMMON"
		value=$?
                if [ $value -ne 0 ]; then
                	echo "Copying of config_utility failed. Return value: $value" | tee -a $LOG
                        AbortInstall
                fi
				
		#Writing of PATH in the registry file
		echo "Writing of PATH in the registry file" >> $LOG
	        ./config_utility -sa $REGISTRY_FILE $ROOT_NAME $PATH_PARAM $InstallDir
                value=$?
                if [ $value -ne 1 ]; then
                        echo "Cannot write PATH to the registry file. Return value: $value" | tee -a $LOG
			AbortInstall
                fi              
		if [ $MULTI_TAP -eq 0 ];then
		#NORMAL MARKET 
                #Writing of SERVICESTATUS in the registry file
		echo "Writing of SERVICESTATUS in the registry file" >> $LOG
                ./config_utility -sa $REGISTRY_FILE $ROOT_NAME $SERVICESTATUS_PARAM 1
		value=$?
		if [ $value -ne 1 ]; then
			echo "Cannot write SERVICESTATUS to the registry file. Return value: $value" | tee -a $LOG
			AbortInstall
		fi
		#END NORMAL MARKET
		fi

		#Writing of TAP RMS config file path in the registry file
		echo "Writing of TAP RMS config file path in the registry file" >> $LOG
                ./config_utility -sa $REGISTRY_FILE $ROOT_NAME $REPO_CONFIG_FILE_PATH_PARAM $REPO_CONFIG_FILE
                value=$?
                if [ $value -ne 1 ]; then
                        echo "Cannot write REPO_CONFIG_FILE_PATH to the registry file. Return value: $value" | tee -a $LOG
                        AbortInstall
                fi
		
		#Call to check whether system is Federo/Ubuntu for adding cron entries

		Check_Cron_Path

		echo "Creating schedular entries for repository management" >> $LOG
		echo "$TASK_EXEC_TIME_REPO $TASK_COMMAND_REPO" >> $PATH_FOR_CRON_ENTRY
		value=$?
		if [ $value -ne 0 ]; then
			echo "Cron entry of RMS failed. Return value: $value" | tee -a $LOG
			AbortInstall
		fi

		echo "$TASK_EXEC_TIME_REPO_ONREBOOT $TASK_COMMAND_REPO" >> $PATH_FOR_CRON_ENTRY
		value=$?		
		if [ $value -ne 0 ]; then
			echo "Cron entry of RMS on reboot failed. Return value: $value" | tee -a $LOG
			AbortInstall
		fi
		if [ $MULTI_TAP -eq 0 ]; then
		#NORMAL 		
		echo "Creating schedular entry for monitoring service for $BROKER_ID" >> $LOG
		echo "$TASK_EXEC_TIME_MONITORING_ONREBOOT $TASK_COMMAND_MONITORING" >> $PATH_FOR_CRON_ENTRY
		value=$?
		if [ $value -ne 0 ]; then
			echo "Cron entry of Monitoring service on reboot failed. Return value: $value" | tee -a $LOG
			AbortInstall
		fi
		#End NORMAL 
		fi
	else
		if [ $MULTI_TAP -eq 0 ]; then
		#NORMAL MARKET 		
		#echo
		#echo "TAP Service will be restarted. Do you wish to continue?"
		#while true
		#do
		#	echo -e "\nPress Y to continue and Q to quit installation : \c "
		#	read choice
		#
		#		case $choice
		#		in
		#				Y|y)
		#					echo "TAP Service should be restarted. User entered: $choice" >>$LOG
		#					break
		#					;;
		#				Q|q)	
		#					echo "Pressed Q to quit installation. User entered: $choice" >>$LOG
		#					OnExitInstall 1	 
		#					;;
		#				*)	echo -e  "Please enter a valid choice. \c "
		#					echo "Selected choice: $choice is invalid." >>$LOG 
		#		esac
		#done

		#kill the TAP and Monitoring if running
		KillAllProcess $BORKER_ID	
		#END NORMAL
		fi
		#Upgradation of TCMS
		if [ $TCMS_UPGRADE_FLAG -eq 1  ]; then
			
			#kill the TCMS if running
			KillProcess "tcms_ip"			
					
			#Remove the tcms_ip
			echo "Deleting tcms_ip" >> $LOG
			rm -f "$InstallDir/TCMS/BIN/tcms_ip"			
			value=$?
			if [ $value -ne 0 ]; then
                        	echo "Deleting of tcms_ip failed. Return value: $value" | tee -a $LOG
                                AbortInstall
                        fi
			
                       	echo "Copying tcms_ip" >> $LOG
			cp -u "$SetupFilesPath/exe/tcms_ip" "$InstallDir/TCMS/BIN"
			value=$?
			if [ $value -ne 0 ]; then
                        	echo "Copying of tcms_ip failed. Return value: $value" | tee -a $LOG
                                AbortInstall
                        fi				
			
 			cp -pf "$SetupFilesPath/exe/start_tap.sh" "$InstallDir/TCMS/BIN"
			value=$?
			if [ $value -ne 0 ]; then
                        	echo "Copying of start_tap.sh failed. Return value: $value" | tee -a $LOG
                                AbortInstall
                        fi

			#Modifying of TCMS_IP_VERSION in the registry file
			echo "Modifying TCMS_IP_VERSION in the registry file" >> $LOG
                        ./config_utility -sm $REGISTRY_FILE $VERSION_PARAM $TCMS_IP_VERSION_PARAM $TCMS_IP_VER
                        value=$?
                        if [ $value -ne 1 ]; then
                        	echo "Cannot write TCMS_IP_VERSION to the registry file. Return value: $value" | tee -a $LOG
                                AbortInstall
                        fi

		fi

		#Upgradation of RMS
		if [ $RMS_UPGRADE_FLAG -eq 1  ]; then
			
			echo "Deleting tap_ip_repository_management_$BROKER_ID" >> $LOG
			rm -f "$InstallDir/TAP_REPO_MANAGEMENT/BIN/tap_ip_repository_management_$BROKER_ID"
			value=$?
			if [ $value -ne 0 ]; then
                        	echo "Deleting of tap_ip_repository_management_$BROKER_ID failed. Return value: $value" | tee -a $LOG
                                AbortInstall
                        fi

                       	echo "Copying tap_ip_repository_management" >> $LOG
			cp -pf "$SetupFilesPath/exe/tap_ip_repository_management" \
			"$InstallDir/TAP_REPO_MANAGEMENT/BIN/tap_ip_repository_management_$BROKER_ID"
			value=$?
			if [ $value -ne 0 ]; then
                        	echo "Copying of tap_ip_repository_management failed. Return value: $value" | tee -a $LOG
                                AbortInstall
                        fi			
			
                        #Modifying RMS_VERSION in the registry file
			echo "Modifying RMS_VERSION in the registry file" >> $LOG
                        ./config_utility -sm $REGISTRY_FILE $VERSION_PARAM $RMS_VERSION_PARAM $RMS_VER
                        value=$?
                        if [ $value -ne 1 ]; then
                        	echo "Cannot write RMS_VERSION to the registry file. Return value: $value" | tee -a $LOG
                                AbortInstall
                        fi

		fi

		if [ $MULTI_TAP -eq 0 ]; then
		#NORMAL MARKET 		
		#Upgradation of Monitoring service
		if [ $TAP_MONITORING_UPGRADE_FLAG -eq 1  ]; then
			
			echo "Deleting tap_ip_monitoring_service_$BROKER_ID" >> $LOG
			rm -f "$InstallDir/TAP_MONITORING/BIN/tap_ip_monitoring_service_$BROKER_ID"
			value=$?
			if [ $value -ne 0 ]; then
                        	echo "Deleting of tap_ip_monitoring_service_$BROKER_ID failed. Return value: $value" | tee -a $LOG
                                AbortInstall
                        fi

			echo "Copying tap_ip_monitoring_service" >> $LOG
			cp -pf "$SetupFilesPath/exe/tap_ip_monitoring_service" \
			"$InstallDir/TAP_MONITORING/BIN/tap_ip_monitoring_service_$BROKER_ID"
			value=$?
			if [ $value -ne 0 ]; then
                        	echo "Copying of tap_ip_monitoring_service_$BROKER_ID failed. Return value: $value" | tee -a $LOG
                                AbortInstall
                        fi
			
			echo "Copying monitoring service configuration file" >> $LOG
			cp "$SetupFilesPath/config/tap_monitoring" "$InstallDir/TAP_MONITORING/CONFIG"
			value=$?
			if [ $value -ne 0 ]; then
				 echo "Copying of monitoring service configuration file failed. Return value: $value" | tee -a $LOG
				 AbortInstall
			fi
			out_line="<configurationFile             data='/etc/TAP_REGISTRY/$BROKER_ID'                                info='This Is The Global TAP Configuration File'/>"

			> "$InstallDir/TAP_MONITORING/CONFIG/tap_monitoring_$BROKER_ID"
			while read line;do

				case $line in

			     *etc*)
				    echo -e "$out_line" >> "$InstallDir/TAP_MONITORING/CONFIG/tap_monitoring_$BROKER_ID"
					value=$?
					if [ $value -ne 0 ]; then
					     echo "Modifying of tap monitoring service config file failed. Return value: $value" | tee -a $LOG
						 AbortInstall
					fi				 
				 ;;
				*)
					printf "%s\n" "$line" >> "$InstallDir/TAP_MONITORING/CONFIG/tap_monitoring_$BROKER_ID"
				 ;;
				esac
			done < "$InstallDir/TAP_MONITORING/CONFIG/tap_monitoring"

			rm -f "$InstallDir/TAP_MONITORING/CONFIG/tap_monitoring"
			echo "./TAP_MONITORING/BIN/tap_ip_monitoring_service_$BROKER_ID -c ./TAP_MONITORING/CONFIG/tap_monitoring_$BROKER_ID &">"$InstallDir/run_tap_monitoring_$BROKER_ID.sh"
			value=$?
			if [ $value -ne 0 ]; then
			  echo "Modifying of shell script to run tap monitoring service failed. Return value: $value" | tee -a $LOG
			  AbortInstall
			 fi
                        #Modifying of TAP_MONITORING_VERSION in the registry file
			echo "Modifying TAP_MONITORING_VERSION in the registry file" >> $LOG
                        ./config_utility -sm $REGISTRY_FILE $VERSION_PARAM $TAP_MONITORING_VERSION_PARAM \
			$TAP_MONITORING_VER
                        value=$?
                        if [ $value -ne 1 ]; then
                        	echo "Cannot write TAP_MONITORING_VERSION to the registry file. Return value: $value" | tee -a $LOG
                                AbortInstall
                        fi

		fi
		#END NORMAL MARKET
		fi
		#Upgradation of DGU
		if [ $DGU_UPGRADE_FLAG -eq 1 ]; then

			echo "Deleting tap_ip_dgu.sh" >> $LOG
			rm -f "$InstallDir/TAP_DGU/BIN/tap_ip_dgu.sh"	
			value=$?
			if [ $value -ne 0 ]; then
                        	echo "Deleting of tap_ip_dgu.sh failed. Return value: $value" | tee -a $LOG
                                AbortInstall
                        fi

			echo "Copying tap_ip_dgu.sh" >> $LOG			
			cp -pf "$SetupFilesPath/exe/tap_ip_dgu.sh" \
			"$InstallDir/TAP_DGU/BIN"
			value=$?
			if [ $value -ne 0 ]; then
                        	echo "Copying of tap_ip_dgu.sh failed. Return value: $value" | tee -a $LOG
                                AbortInstall
                        fi				
			
                        #Modifying of DGU_VERSION in the registry file
			echo "Modifying DGU_VERSION in the registry file" >> $LOG
                        ./config_utility -sm $REGISTRY_FILE $VERSION_PARAM $DGU_VERSION_PARAM $DGU_VER
                        value=$?
                        if [ $value -ne 1 ]; then
                        	echo "Cannot write DGU_VERSION to the registry file. Return value: $value" | tee -a $LOG
                                AbortInstall
                        fi

		fi


	fi

}

#Market installation
Section() {	
          
		        #RDM Installation                       
				
			#Upgradation case
			if [ $RDM_UPGRADE_FLAG -eq 1 ]; then
#NOW MARKET ONLY
				#kill the tap_ip_rdm_$BROKER_ID if running
				KillProcess "tap_ip_rdm_$BROKER_ID"				
#END NOW MARKET 		
				echo "Deleting tap_ip_rdm_$BROKER_ID" >> $LOG
				rm -f "$InstallDir/TAP_RDM/BIN/tap_ip_rdm_$BROKER_ID"
				value=$?
				if [ $value -ne 0 ]; then
					echo "Deleting of tap_ip_rdm_$BROKER_ID failed. Return value: $value" | tee -a $LOG
					AbortInstall
				fi

				echo "Copying tap_ip_rdm" >> $LOG
				cp -pf "$SetupFilesPath/exe/tap_ip_common" "$InstallDir/TAP_RDM/BIN/tap_ip_rdm_$BROKER_ID"
				value=$?
				if [ $value -ne 0 ]; then
					echo "Copying of tap_ip_rdm failed. Return value: $value" | tee -a $LOG
					AbortInstall
				fi

				# echo "Copying rdm_fix42.xml" >> $LOG
				# cp -u "$SetupFilesPath/config/rdm_fix42.xml" "$InstallDir/TAP_RDM/CONFIG"
				# value=$?
				# if [ $value -ne 0 ]; then
					# echo "Copying of rdm_fix42.xml failed. Return value: $value" | tee -a $LOG
					# AbortInstall
				# fi

				# if [ ! -f "$InstallDir/TAP_RDM/CONFIG/tap_fix_rdm.cfg" ]; then
					# echo "Copying tap_fix_rdm.cfg" >> $LOG
					# cp -pf "$SetupFilesPath/config/tap_fix_rdm.cfg" "$InstallDir/TAP_RDM/CONFIG"
					# value=$?
					# if [ $value -ne 0 ]; then
						# echo "Copying of tap_fix_rdm.cfg failed. Return value: $value" | tee -a $LOG
						# AbortInstall
					# fi

				# fi

				echo "Copying rdm_nip_config.dat" >> $LOG
				cp -u "$SetupFilesPath/config/rdm_nip_config.dat" "$InstallDir/TAP_RDM/CONFIG"
				value=$?
				if [ $value -ne 0 ]; then
					echo "Copying of rdm_nip_config.dat failed. Return value: $value" | tee -a $LOG
					AbortInstall
				fi

				echo "Copying rdm_mkt_config.dat" >> $LOG
				cp -u "$SetupFilesPath/config/rdm_mkt_config.dat" "$InstallDir/TAP_RDM/CONFIG"
				value=$?
				if [ $value -ne 0 ]; then
					echo "Copying of rdm_mkt_config.dat failed. Return value: $value" | tee -a $LOG
					AbortInstall
				fi		

	                	#Modifying of TAP RDM VERSION in the registry file
				echo "Modifying TAP RDM VERSION in the registry file" >> $LOG
                                ./config_utility -sm $REGISTRY_FILE $Index $VERSION_PARAM $TAP_RDM_VER
                                value=$?
                                if [ $value -ne 1 ]; then
                                        echo "Cannot write VERSION to the registry file. Return value: $value" | tee -a $LOG
                                        AbortInstall
                                fi

				#Modifying MAX_TWS_CLIENTS parameter in tap_rdm.ini
				echo "Modifying MAX_TWS_CLIENTS in tap_rdm.ini file" >> $LOG
				./config_utility -m $InstallDir/TAP_RDM/CONFIG/tap_rdm.ini MAX_TWS_CLIENTS $MAX_TWS_CLIENTS_VALUE
				value=$?
				if [ $value -ne 1 ]; then
					echo "Cannot write MAX_TWS_CLIENTS to tap_rdm.ini file. Return value: $value" | tee -a $LOG
					AbortInstall
				fi

								#Writing of mkt_config path  in the tap_rdm.ini file
				echo "Writing of MKTCONFIG_FILE_PATH  in the tap_rdm.ini file" >> $LOG
		                ./config_utility -sa $InstallDir/TAP_RDM/CONFIG/tap_rdm.ini "PARAM" "MKTCONFIG_FILE_PATH" $MKTCONFIG_FILE_PATH
                		value=$?
		                if [ $value -ne 1 ]; then
                		        echo "Cannot write MKTCONFIG_FILE_PATH to the tap_rdm.ini file Return value: $value" | tee -a $LOG
		                        AbortInstall
		                fi

 				#Writing of nip_config path  in the tap_rdm.ini file
				echo "Writing of NIPCONFIG_FILE_PATH  in the tap_rdm.ini file" >> $LOG
		                ./config_utility -sa $InstallDir/TAP_RDM/CONFIG/tap_rdm.ini "PARAM" "NIPCONFIG_FILE_PATH" $NIPCONFIG_FILE_PATH
                		value=$?
		                if [ $value -ne 1 ]; then
                		        echo "Cannot write NIPCONFIG_FILE_PATH to the tap_rdm.ini file Return value: $value" | tee -a $LOG
		                        AbortInstall
		                fi
				
				#Modifying of TAP CONNECTION_TYPE in the INI file
				echo "Writeing TAP CONNECTION_TYPE in the ini file" >> $LOG
				count=`cat $InstallDir/TAP_RDM/CONFIG/tap_rdm.ini |grep $CONNECTION_TYPE_PARAM |wc -l`
				value=$?
			        if [ $value -ne 0 ]; then
					echo "Cannot write CONNECTION_TYPE to the INI file. Return value: $value" | tee -a $LOG
					AbortInstall
				fi

				if [ $count -eq 0 ]; then
					echo "CONNECTION_TYPE=0" >>$InstallDir/TAP_RDM/CONFIG/tap_rdm.ini
				fi

			else
				#Fresh installation case for RDM market
				if [ ! -d "$InstallDir/TAP_RDM/BIN" ]; then
		                        echo "Creating $InstallDir/TAP_RDM/BIN directory" >> $LOG
                       			mkdir -p $InstallDir/TAP_RDM/BIN
					value=$?
		                        if [ $value -ne 0 ]; then
                       			        echo "Creation of $InstallDir/TAP_RDM/BIN directory failed. Return value: $value" | tee -a $LOG
		                                AbortInstall
                       			fi
		                fi

				echo "Copying tap_ip_rdm" >> $LOG
		                cp -pf "$SetupFilesPath/exe/tap_ip_common" "$InstallDir/TAP_RDM/BIN/tap_ip_rdm_$BROKER_ID"
				value=$?
		                if [ $value -ne 0 ]; then
                       			echo "Copying of tap_ip_rdm failed. Return value: $value" | tee -a $LOG
		                        AbortInstall
		                fi
				
				if [ ! -d "$InstallDir/TAP_RDM/CONFIG" ]; then
                                        echo "Creating $InstallDir/TAP_RDM/CONFIG directory" >> $LOG
                                        mkdir $InstallDir/TAP_RDM/CONFIG
					value=$?
                                        if [ $value -ne 0 ]; then
						echo "Creation of $InstallDir/TAP_RDM/CONFIG directory failed. Return value: $value" | tee -a $LOG
                                                AbortInstall
                                        fi
                                fi

				echo "Copying RDM configuration files" >> $LOG
                                cp -pf "$SetupFilesPath/config/tap_rdm.ini" "$SetupFilesPath/config/rdm_nip_config.dat" \
										"$SetupFilesPath/config/rdm_mkt_config.dat" "$InstallDir/TAP_RDM/CONFIG"
				value=$?
                                if [ $value -ne 0 ]; then
					echo "Copying of RDM configuration files failed. Return value: $value" | tee -a $LOG
                                        AbortInstall
                                fi

				#Writing of Broker ID in the configuration file
				echo "Writing of BrokerID in the configuration file" >> $LOG
		                ./config_utility -m $RDM_CONFIG_FILE $BROKER_ID_PARAM $BROKER_ID
                		value=$?
		                if [ $value -ne 1 ]; then
                		        echo "Cannot write $BROKER_ID_PARAM to the $RDM_CONFIG_FILE file Return value: $value" | tee -a $LOG
		                        AbortInstall
		                fi

				if [ ! -d "$InstallDir/TAP_RDM/LOGS" ]; then
                                        echo "Creating $InstallDir/TAP_RDM/LOGS directory" >> $LOG
                                        mkdir -p $InstallDir/TAP_RDM/LOGS
					value=$?
                                        if [ $value -ne 0 ]; then
						echo "Creation of $InstallDir/TAP_RDM/LOGS directory"\
						" failed. Return value: $value" | tee -a $LOG
                                                AbortInstall
                                        fi
                                fi						

				# if [ ! -d "$InstallDir/TAP_RDM/LOGS/FIX_LOGS" ]; then
                                        # echo "Creating $InstallDir/TAP_RDM/LOGS/FIX_LOGS directory" >> $LOG
                                        # mkdir -p $InstallDir/TAP_RDM/LOGS/FIX_LOGS
					# value=$?
                                        # if [ $value -ne 0 ]; then
						# echo "Creation of $InstallDir/TAP_RDM/LOGS/FIX_LOGS directory" \
						# " failed. Return value: $value" | tee -a $LOG
                                                # AbortInstall
                                        # fi
                                # fi
						
				# if [ ! -d "$InstallDir/TAP_RDM/LOGS/FIX_STORE" ]; then
                                       # echo "Creating $InstallDir/TAP_RDM/LOGS/FIX_STORE directory" >> $LOG
                                       # mkdir $InstallDir/TAP_RDM/LOGS/FIX_STORE
  				       # value=$?
                                       # if [ $value -ne 0 ]; then
                                               # echo "Creation of $InstallDir/TAP_RDM/LOGS/FIX_STORE directory" \
						# " failed. Return value: $value" | tee -a $LOG
                                               # AbortInstall
                                       # fi
                                # fi

				if [ ! -d "$InstallDir/TAP_RDM/REPOSITORY" ]; then
                                       echo "Creating $InstallDir/TAP_RDM/REPOSITORY directory" >> $LOG
                                       mkdir $InstallDir/TAP_RDM/REPOSITORY
       				       value=$?
                                       if [ $value -ne 0 ]; then
                                               echo "Creation of $InstallDir/TAP_RDM/REPOSITORY directory" \
						" failed. Return value: $value" | tee -a $LOG
                                               AbortInstall
                                       fi
                                fi		                
				if [ $MULTI_TAP -eq 0 ]; then
				#NORMAL MARKETS
		                #Writing of INTERFACE_THREAD_INTERACTIVE_PORT in the registry file
				echo "Writing of INTERFACE_THREAD_INTERACTIVE_PORT in the registry file" >> $LOG
		                ./config_utility -sa $REGISTRY_FILE $Index \
				$INTERFACE_THREAD_INTERACTIVE_PORT_PARAM $INTERFACE_THREAD_INTERACTIVE_PORT_RDM
                		value=$?
		                if [ $value -ne 1 ]; then
                		        echo "Cannot write INTERFACE_THREAD_INTERACTIVE_PORT to the registry file:" \
					"Return value: $value" | tee -a $LOG
		                        AbortInstall
		                fi

				#Writing of INTERFACE_THREAD_NON_INTERACTIVE_PORT in the registry file
				echo "Writing of INTERFACE_THREAD_NON_INTERACTIVE_PORT in the registry file" >> $LOG
                                ./config_utility -sa $REGISTRY_FILE $Index \
				$INTERFACE_THREAD_NON_INTERACTIVE_PORT_PARAM $INTERFACE_THREAD_NON_INTERACTIVE_PORT_RDM
                                value=$?
                                if [ $value -ne 1 ]; then
                                        echo "Cannot write INTERFACE_THREAD_NON_INTERACTIVE_PORT to the registry file:" \
                                        "Return value: $value" | tee -a $LOG
                                        AbortInstall
                                fi
				#END NORMAL MARRKET
				fi
				
				#Writing of CONFIG_FILE_PATH in the registry file
				echo "Writing of CONFIG_FILE_PATH in the registry file" >> $LOG
				./config_utility -sa $REGISTRY_FILE $Index $CONFIG_FILE_PATH_PARAM \
				$RDM_CONFIG_FILE
				value=$?
				if [ $value -ne 1 ]; then					
				echo "Cannot write CONFIG_FILE_PATH to the registry file. Return value: $value" | tee -a $LOG
				AbortInstall
				fi

				# #Writing of FIX_CONFIG_FILE_PATH in the registry file
				# echo "Writing of FIX_CONFIG_FILE_PATH in the registry file" >> $LOG
				# ./config_utility -sa $REGISTRY_FILE $Index $FIX_CONFIG_FILE_PATH_PARAM \
				# "$InstallDir/TAP_RDM/CONFIG/tap_fix_rdm.cfg"
				# value=$?
				# if [ $value -ne 1 ]; then
				# echo "Cannot write FIX_CONFIG_FILE_PATH to the registry file. Return value: $value" | tee -a $LOG
				# AbortInstall
				# fi

                                #Writing of TAP RDM exe PATH in the registry file
				echo "Writing of TAP RDM exe PATH in the registry file" >> $LOG
                                ./config_utility -sa $REGISTRY_FILE $Index $PATH_PARAM \
				"$InstallDir/TAP_RDM/BIN/tap_ip_rdm_$BROKER_ID"
                                value=$?
                                if [ $value -ne 1 ]; then
                                        echo "Cannot write PATH for TAP RDM exe to the registry file. Return value: $value" | tee -a $LOG
                                        AbortInstall
                                fi

				 #Writing of TAP RDM ARGUMET in the registry file
				 echo "Writing of TAP RDM ARGUMET in the registry file" >> $LOG
                                ./config_utility -sa $REGISTRY_FILE $Index $ARGUMENT_PARAM \
				"$InstallDir/TAP_RDM/CONFIG/tap_rdm.ini"
                                value=$?
                                if [ $value -ne 1 ]; then
                                        echo "Cannot write ARGUMENT for TAP RDM to the registry file. Return value: $value" | tee -a $LOG
                                        AbortInstall
                                fi

                                #Make the logs and repository paths entry in the repo config file
				echo "Writing the RDM logs path entry in the repo config file" >> $LOG
                                ./config_utility -sa $REPO_CONFIG_FILE $PATHS_PARAM LOG_FILE_PATH_13 \
				"../../TAP_RDM/LOGS"
                                value=$?
                                if [ $value -ne 1 ]; then
                                        echo "Cannot write LOG_FILE_PATH_13 to the repository manager configuration file:" \
					" Return value: $value" | tee -a $LOG
                                        AbortInstall
                                fi

				echo "Writing the RDM repository path entry in the repo config file" >> $LOG
				./config_utility -sa $REPO_CONFIG_FILE $PATHS_PARAM REPOSITORY_FILE_PATH_13 \
				"../../TAP_RDM/REPOSITORY"
                                value=$?
                                if [ $value -ne 1 ]; then
                                        echo '"Cannot write REPOSITORY_FILE_PATH_13 to the repository manager configuration file: \
                                        Return value: $value"' | tee -a $LOG
                                        AbortInstall
                                fi
				
	                	#Modifying of TAP RDM VERSION in the registry file
				echo "Modifying RDM VERSION in the registry file" >> $LOG
                                ./config_utility -sm $REGISTRY_FILE $Index $VERSION_PARAM $TAP_RDM_VER
                                value=$?
                                if [ $value -ne 1 ]; then
                                        echo "Cannot write RDM VERSION to the registry file. Return value: $value" | tee -a $LOG
                                        AbortInstall
                                fi
#NOW MARKET SPECIFIC ?? CHECK IF NEEDED FOR NORMAL MARKETS
				#Reading of COUNT from the registry common file
				./config_utility -sg $COMMON_FILE $ROOT_NAME $COUNT_PARAM
				value=$?
				if [ $value -ne 0 ]; then
					 echo "Reading of $COUNT_PARAM from $COMMON_FILE failed. Return value: $value" | tee -a $LOG
					 AbortInstall
				fi
				export COUNT_OF_BROKERS=`cat tap_val.txt`

				COUNT_OF_BROKERS=`expr $COUNT_OF_BROKERS + $INSTALLATION_COUNT`
				echo "Number of brokers installed on machine: $COUNT_OF_BROKERS " >> $LOG
				
				echo "Writing the COUNT in the registry common file" >> $LOG
				./config_utility -sm $COMMON_FILE $ROOT_NAME $COUNT_PARAM $COUNT_OF_BROKERS
				value=$?
				if [ $value -ne 1 ]; then
					echo "Cannot write $COUNT_PARAM to the $COMMON_FILE file: Return value: $value" | tee -a $LOG
					AbortInstall
				fi
#END NORMAL MARKETS

			fi
			
			#Call to RegEntry for updation of tcp parameters
			RegEntry
                      
}


PostInstall() {	

		
	cd "$InstallDir/TAP_COMMON"

        #Read the CONNECTION_TYPE from registry file

	echo "Modifying the CONNECTION_TYPE in the registry file" >> $LOG
	./config_utility -sm $REGISTRY_FILE $ROOT_NAME $COUNT_PARAM $TAP_REG_MAX_COUNT
	value=$?
	if [ $value -ne 1 ]; then
		echo "Cannot write CONNECTION_TYPE to the registry. Return value: $value" | tee -a $LOG
		AbortInstall
	fi

        #Read the COUNT from registry file
	echo "Reading the COUNT from the registry file" >> $LOG
        ./config_utility -sg $REGISTRY_FILE $ROOT_NAME $COUNT_PARAM
	value=$?
        if [ $value -eq 0 ]; then
 		export registry_value=`cat tap_val.txt`
		if [ $TAP_REG_MAX_COUNT -gt $registry_value ]; then
			echo "Modifying the COUNT in the registry file" >> $LOG
			./config_utility -sm $REGISTRY_FILE $ROOT_NAME $COUNT_PARAM $TAP_REG_MAX_COUNT
			value=$?
			if [ $value -ne 1 ]; then
				echo "Cannot write TAP_REG_COUNT to the registry. Return value: $value" | tee -a $LOG
				AbortInstall
			fi

		fi
	else

		echo "Writing the COUNT in the registry file" >> $LOG
		./config_utility -sa $REGISTRY_FILE $ROOT_NAME $COUNT_PARAM $TAP_REG_MAX_COUNT
		value=$?
		if [ $value -ne 1 ]; then
			echo "Cannot write TAP_REG_COUNT to the registry. Return value: $value" | tee -a $LOG
			AbortInstall
		fi
	fi

	 #Read the NUMBER_OF_LOGS entry from repo config file
	 echo "Reading the NUMBER_OF_LOGS from the repo config file" >> $LOG
        ./config_utility -sg $REPO_CONFIG_FILE $PATHS_PARAM $NUMBER_OF_LOGS_PARAM
        value=$?
        if [ $value -eq 0 ]; then
                export registry_value=`cat tap_val.txt`
                if [ $TAP_REPO_MAX_INDEX -gt $registry_value ]; then
			echo "Modifying the NUMBER_OF_LOGS in the repo config file" >> $LOG
                        ./config_utility -sm $REPO_CONFIG_FILE $PATHS_PARAM $NUMBER_OF_LOGS_PARAM \
			$TAP_REPO_MAX_INDEX
                        value=$?
                        if [ $value -ne 1 ]; then
                                echo "Cannot write NUMBER_OF_LOGS to the repo config file. Return value: $value" | tee -a $LOG
                                AbortInstall
                        fi

                fi
        else

		echo "Writing the NUMBER_OF_LOGS in the repo config file" >> $LOG
                ./config_utility -sa $REPO_CONFIG_FILE $PATHS_PARAM $NUMBER_OF_LOGS_PARAM \
                $TAP_REPO_MAX_INDEX
                value=$?
                if [ $value -ne 1 ]; then
 	               echo "Cannot write NUMBER_OF_LOGS to the repo config file. Return value: $value" | tee -a $LOG
                       AbortInstall
                fi

	fi

	#Writing TCMS logs folder path
	echo "Writing the TCMS_LOG_FILES_PATH in the registry file" >> $LOG
        ./config_utility -sa $REGISTRY_FILE $ROOT_NAME $TCMS_LOG_FILES_PATH_PARAM "$InstallDir/TCMS/LOGS"
        value=$?
        if [ $value -ne 1 ]; then
	        echo "Cannot write $TCMS_LOG_FILES_PATH_PARAM to the registry. Return value: $value" | tee -a $LOG
                AbortInstall
        fi
	
        #Modifying of TAPVERSION in the registry file
	echo "Modifying TAPVERSION in the registry file" >> $LOG
        ./config_utility -sm $REGISTRY_FILE $ROOT_NAME $TAPVERSION_PARAM $PRODUCT_VERSION	
        value=$?
        if [ $value -ne 1 ]; then
                echo "Cannot write $TAPVERSION_PARAM to the registry file. Return value: $value" | tee -a $LOG
                AbortInstall
        fi
	
	if [ $TCMS_UPGRADE_FLAG -eq 0 ]; then
		#Modifying of TCMS_IP_VERSION in the registry file
		echo "Modifying TCMS_IP_VERSION in the registry file" >> $LOG
		./config_utility -sm $REGISTRY_FILE $VERSION_NAME $TCMS_IP_VERSION_PARAM $TCMS_IP_VER
		value=$?
		if [ $value -ne 1 ]; then
			echo "Cannot write $TCMS_IP_VERSION_PARAM to the registry file. Return value: $value" | tee -a $LOG
			AbortInstall
		fi
	fi

	if [ $RMS_UPGRADE_FLAG -eq 0 ]; then
		#Modifying of RMS_VERSION in the registry file
		echo "Modifying RMS_VERSION in the registry file" >> $LOG
		./config_utility -sm $REGISTRY_FILE $VERSION_NAME $RMS_VERSION_PARAM $RMS_VER
		value=$?
		if [ $value -ne 1 ]; then
			echo "Cannot write $RMS_VERSION_PARAM to the registry file. Return value: $value" | tee -a $LOG
			AbortInstall
		fi	
	fi
	if [ $MULTI_TAP -eq 0 ];then
	#NORMAL MARKETS	
	if [ $TAP_MONITORING_UPGRADE_FLAG -eq 0 ]; then
		#Modifying of TAP_MONITORING_VERSION in the registry file
		echo "Modifying TAP_MONITORING_VERSION in the registry file" >> $LOG
		./config_utility -sm $REGISTRY_FILE $VERSION_NAME $TAP_MONITORING_VERSION_PARAM $TAP_MONITORING_VER
		value=$?
		if [ $value -ne 1 ]; then
			echo "Cannot write $TAP_MONITORING_VERSION_PARAM to the registry file. Return value: $value" | tee -a $LOG
			AbortInstall
		fi
	fi
	#END NORMAL MARKETS
	fi
	if [ $DGU_UPGRADE_FLAG -eq 0 ]; then
		#Modifying of DGU_VERSION in the registry file
		echo "Modifying DGU_VERSION in the registry file" >> $LOG
		./config_utility -sm $REGISTRY_FILE $VERSION_NAME $DGU_VERSION_PARAM $DGU_VER
		value=$?
		if [ $value -ne 1 ]; then
			echo "Cannot write $DGU_VERSION_PARAM to the registry file. Return value: $value" | tee -a $LOG
			AbortInstall
		fi
	fi
	
        if [ $UNINSTALLER_UPGRADE_FLAG -eq 0 ]; then
		#Modifying of UNINSTALLER_VERSION in the registry file
		echo "Modifying UNINSTALLER_VERSION in the registry file" >> $LOG
		./config_utility -sm $REGISTRY_FILE $VERSION_NAME $UNINSTALLER_VERSION_PARAM $UNINSTALLER_VER
		value=$?
		if [ $value -ne 1 ]; then
			echo "Cannot write $UNINSTALLER_VERSION_PARAM to the registry file. Return value: $value" | tee -a $LOG
			AbortInstall
		fi
	fi		
	#Make the logs and repository paths of TCMS entry in the repo config file
	echo "Writing the TCMS log path entry in the repo config file" >> $LOG
		./config_utility -sa $REPO_CONFIG_FILE $PATHS_PARAM LOG_FILE_PATH_8\
		"../../TCMS/LOGS"
		value=$?
		if [ $value -ne 1 ]; then
			echo '"Cannot write LOG_FILE_PATH_8 to the repository manager configuration file: \
			Return value: $value"' | tee -a $LOG
			AbortInstall
		fi

	echo "Writing the TCMS repository path entry in the repo config file" >> $LOG
		./config_utility -sa $REPO_CONFIG_FILE $PATHS_PARAM REPOSITORY_FILE_PATH_8 \
		"../../TCMS/REPOSITORY"
		value=$?
		if [ $value -ne 1 ]; then
		echo '"Cannot write REPOSITORY_FILE_PATH_8 to the repository manager configuration file: \
				Return value: $value"' | tee -a $LOG
				AbortInstall
		fi        

		if [ $MULTI_TAP -eq 0 ]; then
		#NORMAL MARKETS
        #Make the logs and repository paths of TAP MONITORING entry in the repo config file
	echo "Writing the TAP MONITORING log path entry in the repo config file" >> $LOG
        ./config_utility -sa $REPO_CONFIG_FILE $PATHS_PARAM LOG_FILE_PATH_$TAP_MONITORING_INDEX \
        "../../TAP_MONITORING/LOGS"
        value=$?
        if [ $value -ne 1 ]; then
                echo "Cannot write LOG_FILE_PATH_$TAP_MONITORING_INDEX to the repository manager configuration file:" \
                " Return value: $value" | tee -a $LOG
                AbortInstall
        fi

	echo "Writing the TAP MONITORING repository path entry in the repo config file" >> $LOG
        ./config_utility -sa $REPO_CONFIG_FILE $PATHS_PARAM REPOSITORY_FILE_PATH_$TAP_MONITORING_INDEX \
        "../../TAP_MONITORING/REPOSITORY"
        value=$?
        if [ $value -ne 1 ]; then
                echo "Cannot write REPOSITORY_FILE_PATH_$TAP_MONITORING_INDEX to the repository manager configuration file:" \
                " Return value: $value" | tee -a $LOG
                AbortInstall
        fi

	#END NORMAL MARKETS
	fi
	#Upgradation of Uninstaller
	if [ $UNINSTALLER_UPGRADE_FLAG -eq 1 ]; then

		echo "Deleting uninstall.sh" >> $LOG
		rm -f "$InstallDir/uninstall.sh"	
		value=$?
		if [ $value -ne 0 ]; then
			echo "Deleting of uninstall.sh failed. Return value: $value" | tee -a $LOG
			AbortInstall
		fi

		echo "Copying uninstall.sh" >> $LOG			
		cp -pf "$SetupFilesPath/exe/uninstall.sh" "$InstallDir"
		value=$?
		if [ $value -ne 0 ]; then
			echo "Copying of uninstall.sh failed. Return value: $value" | tee -a $LOG
			AbortInstall
		fi			
		
		#Modifying of UNINSTALLER_VERSION in the registry file
		echo "Modifying UNINSTALLER_VERSION in the registry file" >> $LOG
		./config_utility -sm $REGISTRY_FILE $VERSION_PARAM $UNINSTALLER_VERSION_PARAM $UNINSTALLER_VER
		value=$?
		if [ $value -ne 1 ]; then
			echo "Cannot write UNINSTALLER_VERSION to the registry file. Return value: $value" | tee -a $LOG
			AbortInstall
		fi

	fi	

	if [ $MULTI_TAP -eq 0 ]; then
	#NORMAL MARKETS
	#Reset the service status flag in the registry. This is required to inform
        #TAP monitoring service so that it can be started.
	echo "Writing of SERVICESTATUS in the registry file" >> $LOG
	./config_utility -sa $REGISTRY_FILE $ROOT_NAME $SERVICESTATUS_PARAM 0
	value=$?
	if [ $value -ne 1 ]; then
		echo "Cannot write SERVICESTATUS to the registry file: Return value: $value" | tee -a $LOG
		AbortInstall
	fi
	echo "Starting the monitoring service" >> $LOG
	"$InstallDir/TAP_MONITORING/BIN/tap_ip_monitoring_service_$BROKER_ID" -c "$InstallDir/TAP_MONITORING/CONFIG/tap_monitoring_$BROKER_ID" &
	value=$?
	if [ $value -ne 0 ]; then
		echo "Cannot start monitoring service. Return value: $value" | tee -a $LOG
		return
	fi

	#END NORMAL MARKETS
	fi

	if [ $MULTI_TAP -eq 1 ]; then
	#ONLY NOW MARKETS
	echo "Exectuing Run TAP script" >> $LOG
	"$InstallDir/TCMS/BIN/start_tap.sh" $BROKER_ID
	value=$?
	if [ $value -ne 0 ]; then
		echo "Cannot execute Run TAP script. Return value: $value" | tee -a $LOG
		return
	fi
	fi
	#FOR TESTING
	chmod -R 777 $InstallDir >> $LOG 2>> $LOG
	echo "All permissions granted" >> $LOG

	SUCCESS_COUNT=`expr $SUCCESS_COUNT + 1`
	LogBuffer=`echo "$LogBuffer\n $BROKER_ID"`
	#END NOW MARKETS	
}


DirPage() {

	if [ $UPGRADE_FLAG -eq 1 ]; then

		echo "TAP is installed at : [$InstallDir]" | tee -a $LOG
		return

	else

		echo "Default destination directory for TAP installation: [/usr/bin]" | tee -a $LOG		
		echo -e "Press Y to continue, N to select another path for TAP installation and Q to quit installation : \c " | tee -a $LOG

		read choice
		echo

		case "$choice"
		in
			Y|y)	#Default path installation
				
				echo "TAP will be installed at : [$InstallDir]"
				;;			
					
			N|n)	until [ -n "$validchoice" ]
				do
					echo -e "Please specify destination directory for TAP installation: \c " | tee -a $LOG
				
					read path
					echo

					if [ ! -d "$path" ]; then
						echo "[$path] is not a directory" | tee -a $LOG

					else
						validchoice=TRUE
						InstallDir=$path/$TAP
						echo "TAP will be installed at : [$InstallDir]" | tee -a $LOG					
					fi

				done
				;;

			Q|q)	#TAP installation is quit
				exit
				;;

			*)
				echo "Please enter a valid choice." | tee -a $LOG
				exit
				;;

		esac

	fi
	
}



#This function is only used for normal NOW installation. Call to this function is to be commented for batch installation.
NOW_PreInstallation() {

#	cd $REGISTRY_DIRECTORY

	if [ -f $COMMON_FILE ]; then

		#Read the TAP path if present
		./config_utility -sg $COMMON_FILE $ROOT_NAME $PATH_PARAM
		value=$?		
		if [ $value -ne 0 ]; then
			echo "Reading of TAP PATH failed. Return value: $value" | tee -a $LOG
			AbortInstall
		fi

		export InstallDir=`cat tap_val.txt`

		echo "Do you wish to upgrade NOW TAP ??" | tee -a $LOG
		echo -e "Press Y to continue upgradation of TAP, N for TAP installation of new broker and Q to quit installation/upgradation : \c " | tee -a $LOG

			read choice
			echo

			case "$choice"
			in
				Y|y)	#Upgradation of TAP
					echo "Upgradation will Stop TAP $MARKET for all Brokers. Do you wish to proceed ??" | tee -a $LOG
					echo -e "Press Y to continue upgradation of TAP and Q to quit upgradation : \c " | tee -a $LOG

					read choice
					echo

					case "$choice"
					in
						Y|y)	#Upgradation of TAP
							Upgrade_NOWTAP
							;;							
						
						Q|q)	#TAP upgradation is quit.
							exit
							;;

						*)
							echo "Please enter a valid choice." | tee -a $LOG
							exit
							;;
					esac				
				;;			
					
				N|n)	#Menu for entering a broker ID.
					Now_Menu_BROKERID
					;;

				Q|q)	#TAP installation is quit
					exit
					;;

				*)
					echo "Please enter a valid choice." | tee -a $LOG
					exit
					;;

			esac

	else
		#Menu for first broker installation.
		Now_Menu_BROKERID
		DirPage
	fi

}



#clear
echo "Installing TAP [Ver.$INSTALLER_VERSION] for Retail Debt Market (RDM) -> " | tee -a $LOG
#echo "Installing TAP Version  [Ver.$INSTALLER_VERSION]." | tee -a $LOG
#echo "It is recommended that, TAP Installation should be done using \"root\" login." | tee -a $LOG
#echo "Also $Setup_zip_file and the installer script should be kept in the same directory." | tee -a $LOG


#To be commented for batch installation.
#Commented for merged installers
#NOW_PreInstallation
#echo $1 $2
if [ $# -ne 2 ]; then
	echo " Invalid count of params passed to RDM script  " >>$LOG
	exit 1
fi
MULTI_TAP=$1
InstallDir=$2
#echo $MULTI_TAP
#echo $InstallDir
#read
TAP_ROOT_DIRECTORY="$InstallDir"
#Loop for installation of brokers from the /tmp/brokerid.txt

for BROKER_ID in `cat $BROKER_ID_FILE`
do
	#It holds the Installation directory of TAP
	InstallDir="$TAP_ROOT_DIRECTORY"

	#It holds the path for cron entry
	PATH_FOR_CRON_ENTRY="/var/spool/cron"
	Installer_value=1
	OnInit $MARKET_INDEX
	if [ $Installer_value -ne 1 ]; then
		echo "Not upgrading TAP RDM for $BROKER_ID" >> $LOG
		continue
	fi	
	PreInstall
	Section $MARKET_INDEX
	PostInstall
	echo "TAP RDM has been installed successfully on your machine." | tee -a $LOG
	echo "Kindly configure TAP using TAP Configuration and Monitoring System [TCMS]." | tee -a $LOG

done

OnExitInstall 0
