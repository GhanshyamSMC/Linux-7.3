#Start TAP script
#
#!/bin/bash

#It holds the installation directory of TAP
InstallDir=

BROKER_ID=$1

#It holds the TAP Registry directory path
REGISTRY_DIRECTORY="/etc/TAP_REGISTRY"

#It holds the TAP Registry file path
REGISTRY_FILE="$REGISTRY_DIRECTORY/$BROKER_ID"

#It holds the TAP common registry file path
COMMON_FILE="$REGISTRY_DIRECTORY/common.txt"

if [ ! -f $COMMON_FILE ]; then
	echo "registry common file missing."
	exit
fi

InstallDir=`cat $COMMON_FILE | grep "PATH" | cut -d "=" -f2`
	
if [ ! -d $InstallDir ]; then
	echo "TAP installed directory not present. Return value: $value"
	exit
fi	

InstallDir="$InstallDir/$BROKER_ID"


if [ -d "$InstallDir/TAP_CM/BIN" ]; then

	#echo "Changing directory to $InstallDir/TAP_CM/BIN"
	cd "$InstallDir/TAP_CM/BIN"
	value=$?
	if [ $value -ne 0 ]; then
		echo "Changing directory to $InstallDir/TAP_CM/BIN failed. Return value: $value"
	fi
	#echo "Starting TAP CM"
	./tap_ip_cm_$BROKER_ID -c ../CONFIG/tap_cm.ini 1> "/dev/null" 2> "/dev/null" &
	
fi


if [ -d "$InstallDir/TAP_FO/BIN" ]; then

	#echo "Changing directory to $InstallDir/TAP_FO/BIN"
	cd "$InstallDir/TAP_FO/BIN"
	value=$?
	if [ $value -ne 0 ]; then
		echo "Changing directory to $InstallDir/TAP_FO/BIN failed. Return value: $value"
	fi
	#echo "Starting TAP FO"
	./tap_ip_fo_$BROKER_ID -c ../CONFIG/tap_fo.ini 1> "/dev/null" 2> "/dev/null" &
	
fi


if [ -d "$InstallDir/TAP_WDM/BIN" ]; then

	#echo "Changing directory to $InstallDir/TAP_WDM/BIN"
	cd "$InstallDir/TAP_WDM/BIN"
	value=$?
	if [ $value -ne 0 ]; then
		echo "Changing directory to $InstallDir/TAP_WDM/BIN failed. Return value: $value"
	fi
	#echo "Starting TAP WDM"
	./tap_ip_wdm_$BROKER_ID -c ../CONFIG/tap_wdm.ini 1> "/dev/null" 2> "/dev/null" &

fi


if [ -d "$InstallDir/TAP_IPO/BIN" ]; then

	#echo "Changing directory to $InstallDir/TAP_IPO/BIN"
	cd "$InstallDir/TAP_IPO/BIN"
	value=$?
	if [ $value -ne 0 ]; then
		echo "Changing directory to $InstallDir/TAP_IPO/BIN failed. Return value: $value"
	fi
	#echo "Starting TAP IPO"
	./tap_ip_ipo_$BROKER_ID -c ../CONFIG/tap_ipo.ini 1> "/dev/null" 2> "/dev/null" &

fi


if [ -d "$InstallDir/TAP_CD/BIN" ]; then

	#echo "Changing directory to $InstallDir/TAP_CD/BIN"
	cd "$InstallDir/TAP_CD/BIN"
	value=$?
	if [ $value -ne 0 ]; then
		echo "Changing directory to $InstallDir/TAP_CD/BIN failed. Return value: $value"
	fi
	#echo "Starting TAP CD"
	./tap_ip_cd_$BROKER_ID -c ../CONFIG/tap_cd.ini 1> "/dev/null" 2> "/dev/null" &
	
fi


if [ -d "$InstallDir/TAP_SLBM/BIN" ]; then

	#echo "Changing directory to $InstallDir/TAP_SLBM/BIN"
	cd "$InstallDir/TAP_SLBM/BIN"
	value=$?
	if [ $value -ne 0 ]; then
		echo "Changing directory to $InstallDir/TAP_SLBM/BIN failed. Return value: $value"
	fi
	#echo "Starting TAP SLBM"
	./tap_ip_slbm_$BROKER_ID -c ../CONFIG/tap_slbm.ini 1> "/dev/null" 2> "/dev/null" &
	
fi


if [ -d "$InstallDir/TAP_MF/BIN" ]; then

	#echo "Changing directory to $InstallDir/TAP_MF/BIN"
	cd "$InstallDir/TAP_MF/BIN"
	value=$?
	if [ $value -ne 0 ]; then
		echo "Changing directory to $InstallDir/TAP_MF/BIN failed. Return value: $value"
	fi
	#echo "Starting TAP MF"
	./tap_ip_mf_$BROKER_ID -c ../CONFIG/tap_mf.ini 1> "/dev/null" 2> "/dev/null" &
	
fi

if [ -d "$InstallDir/TAP_RDM/BIN" ]; then

	#echo "Changing directory to $InstallDir/TAP_RDM/BIN"
	cd "$InstallDir/TAP_RDM/BIN"
	value=$?
	if [ $value -ne 0 ]; then
		echo "Changing directory to $InstallDir/TAP_RDM/BIN failed. Return value: $value"
	fi
	#echo "Starting TAP RDM"
	./tap_ip_rdm_$BROKER_ID -c ../CONFIG/tap_rdm.ini 1> "/dev/null" 2> "/dev/null" &
	
fi