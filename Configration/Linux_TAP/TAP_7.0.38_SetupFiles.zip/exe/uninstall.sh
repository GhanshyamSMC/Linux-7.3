#!/bin/bash
#05/07/2011	2.09	Linux Setup Uninstaller Version(2.0.9)	
#08/04/2013	2.10	Linux Setup Uninstaller Version(2.0.10) RDM market changes
#

USER_ID=$(id -u)
if [ $USER_ID -ne 0 ];then
        echo "Kindly ensure TAP Uninstallation is done using \"root\" login."
        exit
fi

rm -f "/tmp/TAP_UninstallationDetails.log"
value=$?
if [ $value -ne 0 ]; then
    echo "Deletion of TAP_UninstallationDetails.log file failed. Retun value: $value" | tee -a $LOG
	exit
fi
touch "/tmp/TAP_UninstallationDetails.log"
LOG="/tmp/TAP_UninstallationDetails.log"

#It holds the installation directory of TAP
InstallDir=`pwd`

BROKER_ID=`basename $InstallDir`
if [ $BROKER_ID -le 0 ]; then
	echo "Invalid BrokerID. $BROKER_ID" | tee -a $LOG
	exit
fi

#It holds the path for cron entry
PATH_FOR_CRON_ENTRY="/var/spool/cron"

#It holds the user whose cron entry is to be added
CRON_USER="root"

#It is flag indicating PATH_FOR_CRON_ENTRY is added. If set, PATH_FOR_CRON_ENTRY has proper value 
CRON_FLAG=0

#It holds the TAP Registry directory path
REGISTRY_DIRECTORY="/etc/TAP_REGISTRY"

#It holds the TAP Registry file path
REGISTRY_FILE="$REGISTRY_DIRECTORY/$BROKER_ID"

#It holds the TAP common registry file path
COMMON_FILE="$REGISTRY_DIRECTORY/common.txt"

CONFIG_UTILITY_FILE="$InstallDir/TAP_COMMON/config_utility"
REPO_CONFIG_FILE="$InstallDir/TAP_REPO_MANAGEMENT/CONFIG/tap_repo.ini"

#holds the count of installed markets
INSTALL_COUNT=0
#Identifier to distinguish between single TAP or NOW 
MULTI_TAP=0

#it is incremented after every uninstall of market
UN_COUNT=0

buff=
#section in repo config file
PATHS_PARAM=PATHS

#parameters in registry file
PATH_PARAM=PATH
ROOT_NAME=ROOT
COUNT_PARAM="COUNT"
#for Normal Market
SERVICESTATUS_PARAM=SERVICESTATUS
#End normal market
validchoice=""

CM_INSTALL_FLAG=0
FO_INSTALL_FLAG=0
WDM_INSTALL_FLAG=0
IPO_INSTALL_FLAG=0
CD_INSTALL_FLAG=0
SLBM_INSTALL_FLAG=0
MF_INSTALL_FLAG=0
RDM_INSTALL_FLAG=0


#If the process is running, then it will kill the process
#If the process is not running, then it will return
#If the kill of proces fails, uninstaller will abort
KillProcess() {

	sleep 1
	process_name=$1
	if [ $MULTI_TAP -eq 0 ];then
		value=`ps -C "tap_ip_monitoring_service_$BROKER_ID" | grep -v PID | awk '{print $1}'| wc -l`
		if [ $value -gt 0 ]; then
			echo "Trying to kill $process_name process" >> $LOG
			kill -9 `ps -C "tap_ip_monitoring_service_$BROKER_ID" | grep -v PID | awk '{print $1}'` >>$LOG 2>>$LOG
			value=$?
			if [ $value -ne 0 ]; then
				echo "Cannot kill tap_ip_monitoring_service_$BROKER_ID process Return value: $value" | tee -a $LOG
				exit
			fi
			echo "Process tap_ip_monitoring_service_$BROKER_ID killed successfully" >> $LOG
		fi
	fi

	value=`ps -C $process_name | grep -v PID | awk '{print $1}'| wc -l`
	if [ $value -gt 0 ]; then
		echo "Trying to kill $process_name process" >> $LOG
		kill -9 `ps -C $process_name | grep -v PID | awk '{print $1}'` >>$LOG 2>>$LOG
		value=$?
		if [ $value -ne 0 ]; then
			echo "Cannot kill $process_name process Return value: $value" | tee -a $LOG
			exit
		fi
		echo "Process $process_name killed successfully" >> $LOG
	fi

	return
}

#If the process is running, and all option is selected then it will kill all the process
#If the none process is not running, then it will return
#If the kill of proces fails, uninstaller will abort
KillAllProcess() {
	
	sleep 1
	if [ $MULTI_TAP -eq 0 ];then
		value=`ps -C "tap_ip_monitoring_service_$BROKER_ID" | grep -v PID | awk '{print $1}'| wc -l`
		if [ $value -gt 0 ]; then
			echo "Trying to kill monitoring process" >> $LOG
			kill -9 `ps -C "tap_ip_monitoring_service_$BROKER_ID" | grep -v PID | awk '{print $1}'` >>$LOG 2>>$LOG
			value=$?
			if [ $value -ne 0 ]; then
				echo "Cannot kill tap_ip_monitoring_service_$BROKER_ID process Return value: $value" | tee -a $LOG
				exit
			fi
			echo "Process tap_ip_monitoring_service_$BROKER_ID killed successfully" >> $LOG
		fi
	fi

	value=`ps ax |grep -w -e "tap_ip_cm_$BROKER_ID" -e "tap_ip_fo_$BROKER_ID" -e "tap_ip_wdm_$BROKER_ID" -e "tap_ip_ipo_$BROKER_ID" -e "tap_ip_cd_$BROKER_ID" -e "tap_ip_slbm_$BROKER_ID" -e "tap_ip_mf_$BROKER_ID"  -e "tap_ip_rdm_$BROKER_ID" |grep -v "grep" |wc -l` 2>>$LOG
	if [ $value -ge 1 ]; then
		echo "Trying to kill tap_ip process of $BROKER_ID" >> $LOG
		kill -9 `ps ax |grep -w -e "tap_ip_cm_$BROKER_ID" -e "tap_ip_fo_$BROKER_ID" -e "tap_ip_wdm_$BROKER_ID" -e "tap_ip_ipo_$BROKER_ID" -e "tap_ip_cd_$BROKER_ID" -e "tap_ip_slbm_$BROKER_ID" -e "tap_ip_mf_$BROKER_ID" -e "tap_ip_rdm_$BROKER_ID" | awk '{print $1}'` >>$LOG 2>>$LOG
		value=$?
		if [ $value -ne 0 ]; then
			echo "Cannot kill tap process Return value: $value" | tee -a $LOG
			exit
		fi
		echo "Process of $BROKER_ID killed successfully" >> $LOG
	fi

	return
}
#This function will set the PATH_FOR_CRON_ENTRY variable to proper value based on Federo/Ubuntu
Check_Cron_Path() {

	#Check whether installation is on Federo/Ubuntu.
	if [ -d "$PATH_FOR_CRON_ENTRY/crontabs" ]; then
		echo "Uninstalling on Ubuntu configuration" >> $LOG
		PATH_FOR_CRON_ENTRY="$PATH_FOR_CRON_ENTRY/crontabs/$CRON_USER"			
		
	else
		echo "Uninstalling on Federo Linux configuration" >> $LOG
		PATH_FOR_CRON_ENTRY="$PATH_FOR_CRON_ENTRY/$CRON_USER"			
		
	fi

	echo "Path of Cron entry file is $PATH_FOR_CRON_ENTRY" >> $LOG

	#Flag is used in AbortInstall and Uninstall, to check whether cron entries are added on the system
	CRON_FLAG=1
	return

}


OnUninstSuccess() {

	if [ $UN_COUNT -eq $INSTALL_COUNT ]; then

		#Kill TCMS executable if it is running
		KillProcess "tcms_ip"

	if [ -f $InstallDir/TAP_AGENT/agent_uninstaller.sh ];then
		#Normal Market
		# TAP_AGENT uninstallation call.
		bash "$InstallDir/TAP_AGENT/agent_uninstaller.sh" >>$LOG 2>>$LOG
		#End normal market
	fi
		rm -Rf "$InstallDir/TAP_CM/BIN"
		rm -Rf "$InstallDir/TAP_CM/CONFIG"

		rm -Rf "$InstallDir/TAP_FO/BIN"
		rm -Rf "$InstallDir/TAP_FO/CONFIG"
		
		rm -Rf "$InstallDir/TAP_WDM/BIN"
		rm -Rf "$InstallDir/TAP_WDM/CONFIG"

		rm -Rf "$InstallDir/TAP_IPO/BIN"
		rm -Rf "$InstallDir/TAP_IPO/CONFIG"

		rm -Rf "$InstallDir/TAP_CD/BIN"
		rm -Rf "$InstallDir/TAP_CD/CONFIG"

		rm -Rf "$InstallDir/TAP_SLBM/BIN"
		rm -Rf "$InstallDir/TAP_SLBM/CONFIG"

		rm -Rf "$InstallDir/TAP_MF/BIN"
		rm -Rf "$InstallDir/TAP_MF/CONFIG"

		rm -Rf "$InstallDir/TAP_RDM/BIN"
		rm -Rf "$InstallDir/TAP_RDM/CONFIG"		

		rm -Rf "$InstallDir/TAP_REPO_MANAGEMENT"
		rm -Rf "$InstallDir/TCMS"
		rm -Rf "$InstallDir/TAP_DGU"		
		if [ $MULTI_TAP -eq 0 ];then
			#Normal Market
			rm -Rf "$InstallDir/TAP_MONITORING" >>$LOG 2>>$LOG
			#End normal market
		fi
		rm -f "$InstallDir/uninstall.sh"

		#Deleting the shortcut to tcms
		rm -f "$InstallDir/tcms_ip"

		#Deleting the shortcut to dgu
		rm -f "$InstallDir/tap_ip_dgu.sh"

		#Deleting the shell script to start TCMS
		rm -f "$InstallDir/run_tcms.sh"

		#Deleting the shell script to start TAP
		rm -f "$InstallDir/run_tap.sh"
		
		if [ $MULTI_TAP -eq 0 ];then		
		#Normal Market
		#Deleting the shell script of running monitoring service
			rm -f "$InstallDir/run_tap_monitoring_$BROKER_ID.sh" >>$LOG 2>>$LOG
		#end normal market
		fi

		rm -f "$REGISTRY_FILE"


		#Reading of COUNT from the registry common file
		./config_utility -sg $COMMON_FILE $ROOT_NAME $COUNT_PARAM
		value=$?
		if [ $value -ne 0 ]; then
			 echo "Reading of $COUNT_PARAM from $COMMON_FILE failed. Return value: $value" | tee -a $LOG
			 AbortInstall
		fi
		export COUNT_OF_BROKERS=`cat tap_val.txt`

		COUNT_OF_BROKERS=`expr $COUNT_OF_BROKERS - 1`
				
		echo "Writing the COUNT in the registry common file" >> $LOG
		./config_utility -sm $COMMON_FILE $ROOT_NAME $COUNT_PARAM $COUNT_OF_BROKERS
		value=$?
		if [ $value -ne 1 ]; then
			echo "Cannot write $COUNT_PARAM to the $COMMON_FILE file: Return value: $value" | tee -a $LOG
			AbortInstall
		fi

		rm -Rf "$InstallDir/TAP_COMMON"

		cd "$REGISTRY_DIRECTORY"

		chmod -R 777 "$REGISTRY_DIRECTORY"

		if [ $MULTI_TAP -eq 0 ];then	
		    if [ $COUNT_OF_BROKERS  -eq 0 ];then	   
			rm -rf "$REGISTRY_DIRECTORY/inst_type" >>$LOG 2>>$LOG
			fi
		fi

		if [ `ls | wc -l` -eq 1 ]; then			
			echo "Removing TAP_REGISTRY directory" >> $LOG
			rm -rf "$REGISTRY_DIRECTORY"
		fi
		
		#This function will set the PATH_FOR_CRON_ENTRY variable to proper value based on Federo/Ubuntu
		Check_Cron_Path

		if [ $CRON_FLAG -eq 1 ]; then

			echo "Removing schedular entries" >> $LOG
			echo "Copy of cron entry is kept at /tmp/cron_backup" >> $LOG
			cp  -f $PATH_FOR_CRON_ENTRY "/tmp/cron_backup"
			
			if [ $MULTI_TAP -eq 0 ];then
				#For NORMAL/TRIMMED MARKET
				grep -v -w  "tap_ip_monitoring_service_$BROKER_ID" $PATH_FOR_CRON_ENTRY > /tmp/new_cron_1.txt
				grep -v -w  "tap_ip_repository_management_$BROKER_ID" /tmp/new_cron_1.txt > /tmp/new_cron.txt
				#End NORMAL MARKET			
			else
				grep -v -w "tap_ip_repository_management_$BROKER_ID" $PATH_FOR_CRON_ENTRY > /tmp/new_cron.txt
			fi
			
			diff $PATH_FOR_CRON_ENTRY /tmp/new_cron.txt >> $LOG

			cp -f /tmp/new_cron.txt $PATH_FOR_CRON_ENTRY >> $LOG
			value=$?
			if [ $value -ne 0 ]; then
				echo "Copy of /tmp/new_cron.txt to the $PATH_FOR_CRON_ENTRY failed: Return value: $value" | tee -a $LOG
				echo "Reverting back /tmp/cron_backup to $PATH_FOR_CRON_ENTRY" | tee -a $LOG
				cp -f /tmp/cron_backup $PATH_FOR_CRON_ENTRY >> $LOG
				echo "TAP Uninstallation failed." | tee -a $LOG
				exit

			fi

		fi

		echo "TAP was completely removed from your computer." | tee -a $LOG

	else
		if [ -f `echo TAP_MONITORING/BIN/tap_ip_monitoring_service_$BROKER_ID` ];then
		#NORMAL MARKET
			echo "The selected TAP components were removed from your computer. TAP Service will start now." | tee -a $LOG
		
			./config_utility -sa $REGISTRY_FILE $ROOT_NAME $SERVICESTATUS_PARAM 0
			value=$?
			if [ $value -ne 1 ]; then
				echo "Cannot write SERVICESTATUS to the registry file: Return value: $value" | tee -a $LOG
			fi

			"$InstallDir/TAP_MONITORING/BIN/tap_ip_monitoring_service_$BROKER_ID" -c "$InstallDir/TAP_MONITORING/CONFIG/tap_monitoring_$BROKER_ID" &
			value=$?
			if [ $value -ne 0 ]; then
				echo "Unable to start monitoring service, Please start the monitoring service manually." | tee -a $LOG			
			fi
			#END NORMAL MARKETS
		fi
	fi

	echo "LOGS and REPOSITORY folders have to be deleted manually." | tee -a $LOG
	return
}



OnInit() {

	#Check whether /etc/TAP_REGISTRY directory is present.
	if [ ! -d "$REGISTRY_DIRECTORY" ]; then
		echo "TAP_REGISTRY directory missing. Kindly cleanup and reinstall TAP." | tee -a $LOG 
                exit
	fi
	if [ -f /etc/TAP_REGISTRY/inst_type  ];then
		
		inst_type_read=`cat /etc/TAP_REGISTRY/inst_type`
		if [ $inst_type_read = m ];then
			MULTI_TAP=0
		fi
	else
			MULTI_TAP=0
	fi

	if [ ! -f $REGISTRY_FILE ]; then
		echo "registry file missing. Kindly cleanup and reinstall TAP." | tee -a $LOG 
                exit
	fi

	if [ ! -f $CONFIG_UTILITY_FILE ]; then
		echo "config_utility file missing. Kindly cleanup and reinstall TAP." | tee -a $LOG 
                exit
	fi

	cd "$InstallDir/TAP_COMMON"
	value=$?
	if [ $value -ne 0 ]; then
		echo "Changing directory to TAP_COMMON failed: Return value: $value" | tee -a $LOG
		exit
	fi
	
	#echo "In CM check"
	./config_utility -sg $REGISTRY_FILE 1 $PATH_PARAM
	value=$?
	if [ $value -eq 0 ]; then
		INSTALL_COUNT=`expr $INSTALL_COUNT + 1`
		buff=`echo "$buff\n1. CM market"`
		CM_INSTALL_FLAG=1
	fi

        #echo "In FO check"
        ./config_utility -sg $REGISTRY_FILE 2 $PATH_PARAM
        value=$?
        if [ $value -eq 0 ]; then
		INSTALL_COUNT=`expr $INSTALL_COUNT + 1`
		buff=`echo "$buff\n2. FO market"`
		FO_INSTALL_FLAG=1
        fi

	#echo "In WDM check"
        ./config_utility -sg $REGISTRY_FILE 3 $PATH_PARAM
        value=$?
        if [ $value -eq 0 ]; then		
		INSTALL_COUNT=`expr $INSTALL_COUNT + 1`
		buff=`echo "$buff\n3. WDM market"`
		WDM_INSTALL_FLAG=1
        fi

	#echo "In IPO check"
        ./config_utility -sg $REGISTRY_FILE 4 $PATH_PARAM
        value=$?
        if [ $value -eq 0 ]; then
		INSTALL_COUNT=`expr $INSTALL_COUNT + 1`
		buff=`echo "$buff\n4. IPO market"`
		IPO_INSTALL_FLAG=1
        fi

	#echo "In CD check"
        ./config_utility -sg $REGISTRY_FILE 5 $PATH_PARAM
        value=$?
        if [ $value -eq 0 ]; then
		INSTALL_COUNT=`expr $INSTALL_COUNT + 1`
		buff=`echo "$buff\n5. CD market"`
		CD_INSTALL_FLAG=1
        fi

	#echo "In SLBM check"
        ./config_utility -sg $REGISTRY_FILE 6 $PATH_PARAM
        value=$?
        if [ $value -eq 0 ]; then
		INSTALL_COUNT=`expr $INSTALL_COUNT + 1`
		buff=`echo "$buff\n6. SLBM market"`
		SLBM_INSTALL_FLAG=1
        fi

	#echo "In MF check"
        ./config_utility -sg $REGISTRY_FILE 7 $PATH_PARAM
        value=$?
        if [ $value -eq 0 ]; then
		INSTALL_COUNT=`expr $INSTALL_COUNT + 1`
		buff=`echo "$buff\n7. MF market"`
		MF_INSTALL_FLAG=1
        fi
		
	#echo "In RDM check"
        ./config_utility -sg $REGISTRY_FILE 8 $PATH_PARAM
        value=$?
        if [ $value -eq 0 ]; then
		INSTALL_COUNT=`expr $INSTALL_COUNT + 1`
		buff=`echo "$buff\n8. RDM market"`
		RDM_INSTALL_FLAG=1
        fi
		
	if [ $INSTALL_COUNT -gt 1 ]; then
		buff=`echo "$buff\nA. All markets"`		
	fi

	buff=`echo "$buff\nQ. Quit"`


	until [ -n "$validchoice" ]
	do
		echo "**************************************" | tee -a $LOG 
		echo "Select the market to be uninstalled" | tee -a $LOG 
		echo -e "$buff	" | tee -a $LOG 
		echo "**************************************" | tee -a $LOG 
		echo -e "Please select one of the above: \c " | tee -a $LOG 
	
		read choice
		echo

		case "$choice"
		in
			1)	#In CM uninstallation
				if [ $CM_INSTALL_FLAG -ne 1 ]; then
					echo "Invalid choice" | tee -a $LOG 
				else
					MARKET_INDEX=1
					validchoice=TRUE
					echo -e "Are you sure you want to proceed uninstalling TAP for Capital Market(Y/N): \c " | tee -a $LOG 
					read readvalue
					echo

					case "$readvalue"
					in
						Y|y)	echo "Uninstalling TAP for Capital Market..." | tee -a $LOG							
							KillProcess "tap_ip_cm_$BROKER_ID"

							rm -f "$InstallDir/TAP_CM/BIN/tap_ip_cm_$BROKER_ID"

							rm -Rf "$InstallDir/TAP_CM/BIN"
							rm -Rf "$InstallDir/TAP_CM/CONFIG"

							./config_utility -sc $REGISTRY_FILE $MARKET_INDEX

							./config_utility -sd $REPO_CONFIG_FILE $PATHS_PARAM \
							 LOG_PATH_$MARKET_INDEX

							./config_utility -sd $REPO_CONFIG_FILE $PATHS_PARAM \
							 REPO_PATH_$MARKET_INDEX

							UN_COUNT=`expr $UN_COUNT + 1`
							;;

						*)	echo "Pressed other then Y to proceed uninstallation" >> $LOG
							exit
							;;
					esac
				fi
				;;

			2)	#In FO uninstallation
				if [ $FO_INSTALL_FLAG -ne 1 ]; then
					echo "Invalid choice" | tee -a $LOG 
				else
					MARKET_INDEX=2
					validchoice=TRUE
					echo -e "Are you sure you want to proceed uninstalling TAP for Futures and Options Market(Y/N): \c " | tee -a $LOG 
					read readvalue
					echo

					case "$readvalue"
					in
						Y|y)	echo "Uninstalling TAP for Futures and Options Market..." | tee -a $LOG 
							KillProcess "tap_ip_fo_$BROKER_ID"
							
							rm -f "$InstallDir/TAP_FO/BIN/tap_ip_fo_$BROKER_ID"

							rm -Rf "$InstallDir/TAP_FO/BIN"
							rm -Rf "$InstallDir/TAP_FO/CONFIG"

							./config_utility -sc $REGISTRY_FILE $MARKET_INDEX

							./config_utility -sd $REPO_CONFIG_FILE $PATHS_PARAM \
							LOG_PATH_$MARKET_INDEX

							./config_utility -sd $REPO_CONFIG_FILE $PATHS_PARAM \
							REPO_PATH_$MARKET_INDEX

							UN_COUNT=`expr $UN_COUNT + 1`			
							;;

						*)	echo "Pressed other then Y to proceed uninstallation" >> $LOG
							exit
							;;
					esac					
				fi
				;;
				
			3)	#In WDM uninstallation
				if [ $WDM_INSTALL_FLAG -ne 1 ]; then
					echo "Invalid choice" | tee -a $LOG 
				else
					MARKET_INDEX=3
					validchoice=TRUE
					echo -e "Are you sure you want to proceed uninstalling TAP for Wholesale and Debt Market(Y/N): \c " | tee -a $LOG 
					read readvalue
					echo

					case "$readvalue"
					in
						Y|y)	echo "Uninstalling TAP for Wholesale and Debt Market..." | tee -a $LOG
							KillProcess "tap_ip_wdm_$BROKER_ID"
							
							;;

						*)	echo "Pressed other then Y to proceed uninstallation" >> $LOG
							exit
							;;
					esac					
				fi
				;;
				
			4)	#In IPO uninstallation
				if [ $IPO_INSTALL_FLAG -ne 1 ]; then
					echo "Invalid choice" | tee -a $LOG 
				else
					MARKET_INDEX=4
					validchoice=TRUE
					echo -e "Are you sure you want to proceed uninstalling TAP for Initial Public Offering Market(Y/N): \c " | tee -a $LOG 
					read readvalue
					echo

					case "$readvalue"
					in
						Y|y)	echo "Uninstalling TAP for Initial Public Offering Market..." | tee -a $LOG
							KillProcess "tap_ip_ipo_$BROKER_ID"

							rm -f "$InstallDir/TAP_IPO/BIN/tap_ip_ipo_$BROKER_ID"
	
        			                	rm -Rf "$InstallDir/TAP_IPO/BIN"
                          			  	rm -Rf "$InstallDir/TAP_IPO/CONFIG"

                            				./config_utility -sc $REGISTRY_FILE $MARKET_INDEX
	
        				                ./config_utility -sd $REPO_CONFIG_FILE $PATHS_PARAM \
                            				LOG_PATH_$MARKET_INDEX

                            				./config_utility -sd $REPO_CONFIG_FILE $PATHS_PARAM \
                            				REPO_PATH_$MARKET_INDEX

                            				UN_COUNT=`expr $UN_COUNT + 1`

							;;

						*)	echo "Pressed other then Y to proceed uninstallation" >> $LOG
							exit
							;;
					esac					
				fi
				;;
				
			5)	#In CD uninstallation
				if [ $CD_INSTALL_FLAG -ne 1 ]; then
					echo "Invalid choice" | tee -a $LOG 
				else
					MARKET_INDEX=5
					validchoice=TRUE
					echo -e "Are you sure you want to proceed uninstalling TAP for Currency Derivative Market(Y/N): \c " | tee -a $LOG 
					read readvalue
					echo

					case "$readvalue"
					in
						Y|y)	echo "Uninstalling TAP for Currency Derivative Market..." | tee -a $LOG
							KillProcess "tap_ip_cd_$BROKER_ID"

							rm -f "$InstallDir/TAP_CD/BIN/tap_ip_cd_$BROKER_ID"

                                                        rm -Rf "$InstallDir/TAP_CD/BIN"
                                                        rm -Rf "$InstallDir/TAP_CD/CONFIG"

                                                        ./config_utility -sc $REGISTRY_FILE $MARKET_INDEX

                                                        ./config_utility -sd $REPO_CONFIG_FILE $PATHS_PARAM \
                                                        LOG_PATH_$MARKET_INDEX

                                                        ./config_utility -sd $REPO_CONFIG_FILE $PATHS_PARAM \
                                                        REPO_PATH_$MARKET_INDEX

                                                        UN_COUNT=`expr $UN_COUNT + 1`
							
							;;

						*)	echo "Pressed other then Y to proceed uninstallation" >> $LOG
							exit
							;;
					esac					
				fi
				;;
				
			6)	#In SLBM uninstallation
				if [ $SLBM_INSTALL_FLAG -ne 1 ]; then
					echo "Invalid choice" | tee -a $LOG 
				else
					MARKET_INDEX=6
					validchoice=TRUE
					echo -e "Are you sure you want to proceed uninstalling TAP for Securities and Ledging Market(Y/N): \c " | tee -a $LOG 
					read readvalue
					echo

					case "$readvalue"
					in
						Y|y)	echo "Uninstalling TAP for Securities and Ledging Market..." | tee -a $LOG 
							KillProcess "tap_ip_slbm_$BROKER_ID"

                                                        rm -f "$InstallDir/TAP_SLBM/BIN/tap_ip_slbm_$BROKER_ID"

                                                        rm -Rf "$InstallDir/TAP_SLBM/BIN"
                                                        rm -Rf "$InstallDir/TAP_SLBM/CONFIG"

                                                        ./config_utility -sc $REGISTRY_FILE $MARKET_INDEX

                                                        ./config_utility -sd $REPO_CONFIG_FILE $PATHS_PARAM \
                                                        LOG_PATH_$MARKET_INDEX

                                                        ./config_utility -sd $REPO_CONFIG_FILE $PATHS_PARAM \
                                                        REPO_PATH_$MARKET_INDEX

                                                        UN_COUNT=`expr $UN_COUNT + 1`

							;;

						*)	echo "Pressed other then Y to proceed uninstallation" >> $LOG
							exit
							;;
					esac					
				fi
				;;
				
			7)	#In MF uninstallation
				if [ $MF_INSTALL_FLAG -ne 1 ]; then
					echo "Invalid choice" | tee -a $LOG 
				else
					MARKET_INDEX=7
					validchoice=TRUE
					echo -e "Are you sure you want to proceed uninstalling TAP for Mutual Fund Market(Y/N): \c " | tee -a $LOG 
					read readvalue
					echo

					case "$readvalue"
					in
						Y|y)	echo "Uninstalling TAP for Mutual Fund Market..." | tee -a $LOG 
							KillProcess "tap_ip_mf_$BROKER_ID"
	
							rm -f "$InstallDir/TAP_MF/BIN/tap_ip_mf_$BROKER_ID"

							rm -Rf "$InstallDir/TAP_MF/BIN"
							rm -Rf "$InstallDir/TAP_MF/CONFIG"

							./config_utility -sc $REGISTRY_FILE $MARKET_INDEX

							./config_utility -sd $REPO_CONFIG_FILE $PATHS_PARAM \
							LOG_PATH_$MARKET_INDEX

							./config_utility -sd $REPO_CONFIG_FILE $PATHS_PARAM \
							REPO_PATH_$MARKET_INDEX

							UN_COUNT=`expr $UN_COUNT + 1`
							;;

						*)	echo "Pressed other then Y to proceed uninstallation" >> $LOG
							exit
							;;
					esac					
				fi
				;;

				
			8)	#In RDM uninstallation
				if [ $RDM_INSTALL_FLAG -ne 1 ]; then
					echo "Invalid choice" | tee -a $LOG 
				else
					MARKET_INDEX=8
					validchoice=TRUE
					echo -e "Are you sure you want to proceed uninstalling TAP for Retail Debt Market (Y/N): \c " | tee -a $LOG 
					read readvalue
					echo

					case "$readvalue"
					in
						Y|y)	echo "Uninstalling TAP for RDM..." | tee -a $LOG 
							KillProcess "tap_ip_rdm_$BROKER_ID"
	
							rm -f "$InstallDir/TAP_RDM/BIN/tap_ip_rdm_$BROKER_ID"

							rm -Rf "$InstallDir/TAP_RDM/BIN"
							rm -Rf "$InstallDir/TAP_RDM/CONFIG"

							./config_utility -sc $REGISTRY_FILE $MARKET_INDEX

							./config_utility -sd $REPO_CONFIG_FILE $PATHS_PARAM \
							LOG_PATH_$MARKET_INDEX

							./config_utility -sd $REPO_CONFIG_FILE $PATHS_PARAM \
							REPO_PATH_$MARKET_INDEX

							UN_COUNT=`expr $UN_COUNT + 1`
							;;

						*)	echo "Pressed other then Y to proceed uninstallation" >> $LOG
							exit
							;;
					esac					
				fi
				;;
				
			A|a)	
				if [ $INSTALL_COUNT -gt 1 ];then
					validchoice=TRUE
					echo -e "Are you sure you want to proceed uninstalling TAP for All Markets(Y/N): \c " | tee -a $LOG
					read readvalue
					echo

					case "$readvalue"
					in
						Y|y)	echo "Uninstalling TAP for All the Markets..." | tee -a $LOG
							KillAllProcess 
							UN_COUNT=$INSTALL_COUNT						
							;;

						*)	echo "Pressed other then Y to proceed uninstallation" >> $LOG
							exit
							;;
					esac
				else
					echo "Pressed other then market index for uninstallation of TAP" >> $LOG
					echo "Invalid choice" | tee -a $LOG
				fi
				;;

			Q|q)
				validchoice=TRUE
				echo "Pressed Q to quit uninstallation" >> $LOG
				exit				
				;;

			*) #Default case
				echo "Pressed other then market index for uninstallation of TAP" >> $LOG
				echo "Invalid choice" | tee -a $LOG
				;;

		esac

	done

}


clear
echo "------------------------------Welcome to TAP Uninstaller------------------------------" | tee -a $LOG 
echo "It is recommended that, TAP Uninstallation should be done using \"root\" login." | tee -a $LOG
echo "Member ID: "[$BROKER_ID]"" | tee -a $LOG
OnInit
OnUninstSuccess
echo "-----------------------------------------END-----------------------------------------" | tee -a $LOG 
